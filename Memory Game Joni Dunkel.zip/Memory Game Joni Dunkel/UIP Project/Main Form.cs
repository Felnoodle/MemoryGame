﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace UIP_Project
{
    public partial class mainForm : Form
    {
        PictureBox[] cards = new PictureBox[20];
        Random rng = new Random();
        string DEFAULTBACK = "hamletti";
        PictureBox firstClick;
        Timer clickDelay = new Timer();
        Timer computerDelay = new Timer();
        Timer computerFail = new Timer();
        bool yourTurn = true;
        int p1Score = 0;
        int p2Score = 0;
        bool singleplayer = true;
        bool player1turn = true;
        string p1Name = "";
        int p1Wins = 0;
        int p1Losses = 0;
        int p1Streak = 0;
        int p1Xp = 0;
        int p1Back = 0;
        int p1Front = 0;
        List<Leaderboard> leaderboardProfiles = new List<Leaderboard>();
        int AIDifficulty = 3;
        string appPath = Path.GetDirectoryName(Application.ExecutablePath);

        class Leaderboard
        {
            public string name { get; set; }
            public int wins { get; set; }
            public int losses { get; set; }
            public int percent { get; set; }
            public int level { get; set; }
        }

        public mainForm()
        {
            Icon = Properties.Resources.apuicon;
            InitializeComponent();
            clickDelay.Interval = 1000;
            clickDelay.Tick += ClickDelay_Tick;
            computerDelay.Interval = 1000;
            computerDelay.Tick += ComputerDelay_Tick;
            computerFail.Interval = 1500;
            computerFail.Tick += ComputerFail_Tick;
            GetProfiles();
            optionsPanel.Location = new Point(mainTitle.Location.X + 20, mainTitle.Location.Y);
            leaderboardsPanel.Location = new Point(mainTitle.Location.X - 80, mainTitle.Location.Y);
            pregamePanel.Location = new Point(mainTitle.Location.X - 30, mainTitle.Location.Y);
            gamePanel.Location = new Point(mainTitle.Location.X - 80, mainTitle.Location.Y);
            Size = new Size(540, 800);
        }

        //Gets the wanted card fronts when starting the game
        private IEnumerable<Image> cardFronts
        {
            get
            {
                if (p1Front == 1)//Poker front selected
                {
                    int rnd = rng.Next(0, 4);//Takes one of the suits randomly
                    if (rnd == 0)
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "pokerBackRed";
                        return new Image[]
                        {
                            Properties.Resources.hearts1,
                            Properties.Resources.hearts2,
                            Properties.Resources.hearts3,
                            Properties.Resources.hearts4,
                            Properties.Resources.hearts5,
                            Properties.Resources.hearts6,
                            Properties.Resources.hearts7,
                            Properties.Resources.hearts8,
                            Properties.Resources.hearts9,
                            Properties.Resources.hearts10
                        };
                    }
                    else if (rnd == 1)
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "pokerBackRed";
                        return new Image[]
                        {
                            Properties.Resources.diamonds1,
                            Properties.Resources.diamonds2,
                            Properties.Resources.diamonds3,
                            Properties.Resources.diamonds4,
                            Properties.Resources.diamonds5,
                            Properties.Resources.diamonds6,
                            Properties.Resources.diamonds7,
                            Properties.Resources.diamonds8,
                            Properties.Resources.diamonds9,
                            Properties.Resources.diamonds10
                        };
                    }
                    else if (rnd == 2)
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "pokerBackBlue";
                        return new Image[]
                        {
                            Properties.Resources.clubs1,
                            Properties.Resources.clubs2,
                            Properties.Resources.clubs3,
                            Properties.Resources.clubs4,
                            Properties.Resources.clubs5,
                            Properties.Resources.clubs6,
                            Properties.Resources.clubs7,
                            Properties.Resources.clubs8,
                            Properties.Resources.clubs9,
                            Properties.Resources.clubs10
                        };
                    }
                    else
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "pokerBackBlue";
                        return new Image[]
                        {
                            Properties.Resources.spade1,
                            Properties.Resources.spade2,
                            Properties.Resources.spade3,
                            Properties.Resources.spade4,
                            Properties.Resources.spade5,
                            Properties.Resources.spade6,
                            Properties.Resources.spade7,
                            Properties.Resources.spade8,
                            Properties.Resources.spade9,
                            Properties.Resources.spade10
                        };
                    }
                }
                else if (p1Front == 2)
                {
                    return new Image[]
                        {
                            Properties.Resources.guilds1,
                            Properties.Resources.guilds2,
                            Properties.Resources.guilds3,
                            Properties.Resources.guilds4,
                            Properties.Resources.guilds5,
                            Properties.Resources.guilds6,
                            Properties.Resources.guilds7,
                            Properties.Resources.guilds8,
                            Properties.Resources.guilds9,
                            Properties.Resources.guilds10
                        };
                }
                else if (p1Front == 3)
                {
                    return new Image[]
                        {
                            Properties.Resources.fancyGuilds1,
                            Properties.Resources.fancyGuilds2,
                            Properties.Resources.fancyGuilds3,
                            Properties.Resources.fancyGuilds4,
                            Properties.Resources.fancyGuilds5,
                            Properties.Resources.fancyGuilds6,
                            Properties.Resources.fancyGuilds7,
                            Properties.Resources.fancyGuilds8,
                            Properties.Resources.fancyGuilds9,
                            Properties.Resources.fancyGuilds10
                        };
                }
                else if (p1Front == 4)
                {
                    //Arcana front has 2 different styles with 3 configurations each. Since there are 21 major arcana
                    //cards, i wanted to have some variance in the images and couldn't figure a way to get random images
                    int rnd = rng.Next(0, 6);
                    if (rnd == 0)
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "arcanaBack1";
                        return new Image[]
                        {
                            Properties.Resources.arcana1I,
                            Properties.Resources.arcana1II,
                            Properties.Resources.arcana1III,
                            Properties.Resources.arcana1IV,
                            Properties.Resources.arcana1V,
                            Properties.Resources.arcana1VI,
                            Properties.Resources.arcana1VII,
                            Properties.Resources.arcana1VIII,
                            Properties.Resources.arcana1IX,
                            Properties.Resources.arcana1X
                        };
                    }
                    if (rnd == 1)
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "arcanaBack1";
                        return new Image[]
                        {
                            Properties.Resources.arcana1XXI,
                            Properties.Resources.arcana1XX,
                            Properties.Resources.arcana1XIX,
                            Properties.Resources.arcana1XVIII,
                            Properties.Resources.arcana1XVII,
                            Properties.Resources.arcana1XVI,
                            Properties.Resources.arcana1XV,
                            Properties.Resources.arcana1XIV,
                            Properties.Resources.arcana1XIII,
                            Properties.Resources.arcana1XII
                        };
                    }
                    if (rnd == 2)
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "arcanaBack1";
                        return new Image[]
                        {
                            Properties.Resources.arcana1,
                            Properties.Resources.arcana1II,
                            Properties.Resources.arcana1IV,
                            Properties.Resources.arcana1VII,
                            Properties.Resources.arcana1IX,
                            Properties.Resources.arcana1XI,
                            Properties.Resources.arcana1XX,
                            Properties.Resources.arcana1XIV,
                            Properties.Resources.arcana1XVII,
                            Properties.Resources.arcana1XIX
                        };
                    }
                    else if (rnd == 3)
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "arcanaBack2";
                        return new Image[]
                        {
                            Properties.Resources.arcana2,
                            Properties.Resources.arcana2I,
                            Properties.Resources.arcana2III,
                            Properties.Resources.arcana2V,
                            Properties.Resources.arcana2VIII,
                            Properties.Resources.arcana2XI,
                            Properties.Resources.arcana2XIII,
                            Properties.Resources.arcana2XV,
                            Properties.Resources.arcana2XVI,
                            Properties.Resources.arcana2XX
                        };
                    }
                    else if (rnd == 4)
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "arcanaBack2";
                        return new Image[]
                        {
                            Properties.Resources.arcana2,
                            Properties.Resources.arcana2I,
                            Properties.Resources.arcana2XI,
                            Properties.Resources.arcana2XVIII,
                            Properties.Resources.arcana2XVII,
                            Properties.Resources.arcana2XVI,
                            Properties.Resources.arcana2XV,
                            Properties.Resources.arcana2XIV,
                            Properties.Resources.arcana2XIII,
                            Properties.Resources.arcana2XII
                        };
                    }
                    else
                    {
                        if (p1Back == p1Front && matchingBox.Checked)
                            DEFAULTBACK = "arcanaBack2";
                        return new Image[]
                        {
                            Properties.Resources.arcana2I,
                            Properties.Resources.arcana2II,
                            Properties.Resources.arcana2III,
                            Properties.Resources.arcana2IV,
                            Properties.Resources.arcana2V,
                            Properties.Resources.arcana2VI,
                            Properties.Resources.arcana2VII,
                            Properties.Resources.arcana2VIII,
                            Properties.Resources.arcana2IX,
                            Properties.Resources.arcana2X
                        };
                    }
                }
                else
                {
                    return new Image[]
                    {
                    Properties.Resources.image1,
                    Properties.Resources.image2,
                    Properties.Resources.image3,
                    Properties.Resources.image4,
                    Properties.Resources.image5,
                    Properties.Resources.image6,
                    Properties.Resources.image7,
                    Properties.Resources.image8,
                    Properties.Resources.image9,
                    Properties.Resources.image10
                    };
                }

            }
        }
        
        //Gets profile data from directory
        private void GetProfiles()
        {
            Directory.CreateDirectory(appPath + "\\MemoryGameProfiles");
            DirectoryInfo profileDirectory = new DirectoryInfo(appPath + "\\MemoryGameProfiles\\");
            FileInfo[] profileFiles = profileDirectory.GetFiles();
            singleProfileList.Items.Clear();
            multiProfileList1.Items.Clear();
            multiProfileList2.Items.Clear();
            profileBox.Items.Clear();
            foreach (FileInfo file in profileFiles)
            {
                string PROFILENAME = Path.GetFileNameWithoutExtension(file.Name);
                singleProfileList.Items.Add(PROFILENAME);
                multiProfileList1.Items.Add(PROFILENAME);
                multiProfileList2.Items.Add(PROFILENAME);
                profileBox.Items.Add(PROFILENAME);
            }
        }

        //Main menu new game button
        private void startButton_Click(object sender, EventArgs e)
        {
            if (gamePanel.Visible == false)
                pregamePanel.Show();
        }

        //Main menu options button
        private void optionsButton_Click(object sender, EventArgs e)
        {
            optionsPanel.Show();
            if (p1Name != "") //updates currently selected profile's score if there is one selected
                ReadScore();
        }

        //Main menu leaderboards button
        private void leaderboardsButton_Click(object sender, EventArgs e)
        {
            leaderboardsPanel.Show();
            CreateLeaderboards();
        }

        //Generates the leaderboards table
        private void CreateLeaderboards()
        {
            DirectoryInfo profileDirectory = new DirectoryInfo(appPath + "\\MemoryGameProfiles\\");
            FileInfo[] profileFiles = profileDirectory.GetFiles();
            //leaderboardProfiles is a 'Leaderboard' class variable list that handles all the information for the
            //leaderboard and makes it easy to sort
            leaderboardProfiles.Clear();
            //This loop gathers all the necessary info from the profile text files and stores them into the Leaderboard class
            foreach (FileInfo file in profileFiles)
            {
                int profileWins = Int16.Parse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + file.Name).Skip(1).Take(1).First());
                int profileLosses = Int16.Parse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + file.Name).Skip(3).Take(1).First());

                int winPercent = 0;
                if (profileLosses == 0 && profileWins == 0)
                    winPercent = 0;
                else
                    winPercent = Convert.ToInt16(Convert.ToDouble(profileWins) / (Convert.ToDouble(profileWins) + Convert.ToDouble(profileLosses)) * 100);
                int profileLevel = (Int16.Parse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + file.Name).Skip(7).Take(1).First())) / 10;
                //Leaderboard class has a variable for each column in the leaderboards
                leaderboardProfiles.Add(new Leaderboard
                {
                    name = Path.GetFileNameWithoutExtension(file.Name),
                    wins = profileWins,
                    losses = profileLosses,
                    percent = winPercent,
                    level = profileLevel,
                });
            }
            leaderboardsTable.Controls.Clear();
            leaderboardsTable.RowCount = profileFiles.Length + 1;
            leaderboardsTable.ColumnCount = 5;
            //Creates the titles for each column in the table
            CreateTitles();
            int row = 1;
            //Populates the table
            foreach (Leaderboard profile in leaderboardProfiles)
            {
                Label nameLabel = new Label { Text = profile.name };
                leaderboardsTable.Controls.Add(nameLabel, 0, row);
                Label winsLabel = new Label { Text = profile.wins.ToString() };
                leaderboardsTable.Controls.Add(winsLabel, 1, row);
                Label lossesLabel = new Label { Text = profile.losses.ToString() };
                leaderboardsTable.Controls.Add(lossesLabel, 2, row);
                Label percentLabel = new Label { Text = profile.percent.ToString() };
                leaderboardsTable.Controls.Add(percentLabel, 3, row);
                Label levelLabel = new Label { Text = profile.level.ToString() };
                leaderboardsTable.Controls.Add(levelLabel, 4, row);
                row++;
            }
        }

        //Creates leaderboard titles
        private void CreateTitles()
        {
            Label name = CreateNameTitle();
            Label wins = CreateWinsTitle();
            Label losses = CreateLossesTitle();
            Label percent = CreatePercentTitle();
            Label level = CreateLevelTitle();
            leaderboardsTable.Controls.Add(name, 0, 0);
            leaderboardsTable.Controls.Add(wins, 1, 0);
            leaderboardsTable.Controls.Add(losses, 2, 0);
            leaderboardsTable.Controls.Add(percent, 3, 0);
            leaderboardsTable.Controls.Add(level, 4, 0);
        }

        private Label CreateNameTitle()
        {
            Label name = new Label()
            {
                Name = "nameLabel",
                Font = new Font(DefaultFont, FontStyle.Bold),
                Text = "Profile Name",
            };
            //Event to sort by the clicked title
            name.Click += new EventHandler(leaderboardTitle_Click);
            return name;
        }

        private Label CreateWinsTitle()
        {
            Label wins = new Label()
            {
                Name = "winsLabel",
                Font = new Font(DefaultFont, FontStyle.Bold),
                Text = "Wins",

            };
            wins.Click += new EventHandler(leaderboardTitle_Click);
            return wins;
        }

        private Label CreateLossesTitle()
        {
            Label losses = new Label()
            {
                Name = "lossesLabel",
                Font = new Font(DefaultFont, FontStyle.Bold),
                Text = "Losses",

            };
            losses.Click += new EventHandler(leaderboardTitle_Click);
            return losses;
        }

        private Label CreatePercentTitle()
        {
            Label percent = new Label()
            {
                Name = "percentLabel",
                Font = new Font(DefaultFont, FontStyle.Bold),
                Text = "Win%",

            };
            percent.Click += new EventHandler(leaderboardTitle_Click);
            return percent;
        }

        private Label CreateLevelTitle()
        {
            Label level = new Label()
            {
                Name = "levelLabel",
                Font = new Font(DefaultFont, FontStyle.Bold),
                Text = "Level",

            };
            level.Click += new EventHandler(leaderboardTitle_Click);
            return level;
        }

        //Called when you click a title in the leaderboard, this event arranges the leaderboard to be in ascending
        //order for the clicked variable and assigns an event to the title so that when it is clicked a second time
        //the leaderboard will be in descending order
        private void leaderboardTitle_Click(object sender, EventArgs e)
        {
            var sorter = (Label)sender;
            //profilesSorted list will take the items from leaderboardProfiles list and sort them as requested
            List<Leaderboard> profilesSorted = new List<Leaderboard>();
            profilesSorted.Clear();
            DirectoryInfo profileDirectory = new DirectoryInfo(appPath + "\\MemoryGameProfiles\\");
            FileInfo[] profileFiles = profileDirectory.GetFiles();
            leaderboardsTable.Controls.Clear();
            CreateTitles();
            //Populates profilesSorted list depending on the sender
            switch (sorter.Text)
            {
                case "Profile Name":
                    //AddRange adds all the items from leaderboardProfiles to profilesSorted
                    //OrderBy changes the order in which they are assigned, depending on the variable
                    profilesSorted.AddRange(leaderboardProfiles.OrderBy(Leaderboard => Leaderboard.name));
                    leaderboardsSubtitle.Text = "Sort by: Name (Desc.)";
                    //Remove old click event and add another one, so a second click will change from descending order
                    //to ascending
                    leaderboardsTable.GetControlFromPosition(0, 0).Click -= new EventHandler(leaderboardTitle_Click);
                    leaderboardsTable.GetControlFromPosition(0, 0).Click += new EventHandler(leaderboardTitle_SecondClick);
                    break;
                case "Wins":
                    profilesSorted.AddRange(leaderboardProfiles.OrderByDescending(Leaderboard => Leaderboard.wins));
                    leaderboardsSubtitle.Text = "Sort by: Wins (Desc.)";
                    leaderboardsTable.GetControlFromPosition(1, 0).Click -= new EventHandler(leaderboardTitle_Click);
                    leaderboardsTable.GetControlFromPosition(1, 0).Click += new EventHandler(leaderboardTitle_SecondClick);
                    break;
                case "Losses":
                    profilesSorted.AddRange(leaderboardProfiles.OrderByDescending(Leaderboard => Leaderboard.losses));
                    leaderboardsSubtitle.Text = "Sort by: Losses (Desc.)";
                    leaderboardsTable.GetControlFromPosition(2, 0).Click -= new EventHandler(leaderboardTitle_Click);
                    leaderboardsTable.GetControlFromPosition(2, 0).Click += new EventHandler(leaderboardTitle_SecondClick);
                    break;
                case "Win%":
                    profilesSorted.AddRange(leaderboardProfiles.OrderByDescending(Leaderboard => Leaderboard.percent));
                    leaderboardsSubtitle.Text = "Sort by: Win% (Desc.)";
                    leaderboardsTable.GetControlFromPosition(3, 0).Click -= new EventHandler(leaderboardTitle_Click);
                    leaderboardsTable.GetControlFromPosition(3, 0).Click += new EventHandler(leaderboardTitle_SecondClick);
                    break;
                case "Level":
                    profilesSorted.AddRange(leaderboardProfiles.OrderByDescending(Leaderboard => Leaderboard.level));
                    leaderboardsSubtitle.Text = "Sort by: Level (Desc.)";
                    leaderboardsTable.GetControlFromPosition(4, 0).Click -= new EventHandler(leaderboardTitle_Click);
                    leaderboardsTable.GetControlFromPosition(4, 0).Click += new EventHandler(leaderboardTitle_SecondClick);
                    break;
                default:
                    MessageBox.Show("you should not see this");
                    break;
            }
            leaderboardsTable.RowCount = profileFiles.Length + 1;
            leaderboardsTable.ColumnCount = 5;
            int row = 1;
            //Repopulate the leaderboard table with profilesSorted
            foreach (Leaderboard profile in profilesSorted)
            {
                Label nameLabel = new Label { Text = profile.name };
                leaderboardsTable.Controls.Add(nameLabel, 0, row);
                Label winsLabel = new Label { Text = profile.wins.ToString() };
                leaderboardsTable.Controls.Add(winsLabel, 1, row);
                Label lossesLabel = new Label { Text = profile.losses.ToString() };
                leaderboardsTable.Controls.Add(lossesLabel, 2, row);
                Label percentLabel = new Label { Text = profile.percent.ToString() };
                leaderboardsTable.Controls.Add(percentLabel, 3, row);
                Label levelLabel = new Label { Text = profile.level.ToString() };
                leaderboardsTable.Controls.Add(levelLabel, 4, row);
                row++;
            }
        }

        //Called when you click the same leaderboard title twice in a row, and arranges the leaderboard in desc. order
        private void leaderboardTitle_SecondClick(object sender, EventArgs e)
        {
            List<Leaderboard> profilesSorted = new List<Leaderboard>();
            profilesSorted.Clear();
            var sorter = (Label)sender;
            leaderboardsTable.Controls.Clear();
            CreateTitles();
            DirectoryInfo profileDirectory = new DirectoryInfo(appPath + "\\MemoryGameProfiles\\");
            FileInfo[] profileFiles = profileDirectory.GetFiles();
            //Board changed from desc. to asc.
            switch (sorter.Text)
            {
                case "Profile Name":
                    profilesSorted.AddRange(leaderboardProfiles.OrderByDescending(Leaderboard => Leaderboard.name));
                    leaderboardsSubtitle.Text = "Sort by: Name (Asc.)";
                    break;
                case "Wins":
                    profilesSorted.AddRange(leaderboardProfiles.OrderBy(Leaderboard => Leaderboard.wins));
                    leaderboardsSubtitle.Text = "Sort by: Wins (Asc.)";
                    break;
                case "Losses":
                    profilesSorted.AddRange(leaderboardProfiles.OrderBy(Leaderboard => Leaderboard.losses));
                    leaderboardsSubtitle.Text = "Sort by: Losses (Asc.)";
                    break;
                case "Win%":
                    profilesSorted.AddRange(leaderboardProfiles.OrderBy(Leaderboard => Leaderboard.percent));
                    leaderboardsSubtitle.Text = "Sort by: Win% (Asc.)";
                    break;
                case "Level":
                    profilesSorted.AddRange(leaderboardProfiles.OrderBy(Leaderboard => Leaderboard.level));
                    leaderboardsSubtitle.Text = "Sort by: Level (Asc.)";
                    break;
                default:
                    MessageBox.Show("you should not see this");
                    break;
            }
            leaderboardsTable.RowCount = profileFiles.Length + 1;
            leaderboardsTable.ColumnCount = 5;
            int row = 1;
            foreach (Leaderboard profile in profilesSorted)
            {
                Label nameLabel = new Label { Text = profile.name };
                leaderboardsTable.Controls.Add(nameLabel, 0, row);
                Label winsLabel = new Label { Text = profile.wins.ToString() };
                leaderboardsTable.Controls.Add(winsLabel, 1, row);
                Label lossesLabel = new Label { Text = profile.losses.ToString() };
                leaderboardsTable.Controls.Add(lossesLabel, 2, row);
                Label percentLabel = new Label { Text = profile.percent.ToString() };
                leaderboardsTable.Controls.Add(percentLabel, 3, row);
                Label levelLabel = new Label { Text = profile.level.ToString() };
                leaderboardsTable.Controls.Add(levelLabel, 4, row);
                row++;
            }
        }

        //Called when leaving leaderboards menu
        private void leaderboardsBackButton_Click(object sender, EventArgs e)
        {
            leaderboardsPanel.Hide();
            leaderboardsSubtitle.Text = "Sort by: Name (Desc.)";
        }

        //Main menu exit button
        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        //Options exit button
        private void optionsExitButton_Click(object sender, EventArgs e)
        {
            optionsPanel.Hide();
        }

        //New singleplayer game selection button
        private void singleplayerButton_Click(object sender, EventArgs e)
        {
            pregameSingleOptions.Show();
            pregameMultiOptions.Hide();
            difficultyMedium.Checked = true;
            sharedPanel.Visible = true;
            if (p1Name != "") //updates currently selected profile's score if there is one selected
                ReadScore();
        }

        //New multiplayer game selection button
        private void multiplayerButton_Click(object sender, EventArgs e)
        {
            pregameSingleOptions.Hide();
            pregameMultiOptions.Show();
            sharedPanel.Visible = true;
            multiFrontDefault.Checked = true;
            multiBackDefault.Checked = true;
        }

        //Event when you change the amount of pairs for the game
        private void pairAmountTextBox_TextChanged(object sender, EventArgs e)
        {
            if (Int32.TryParse(pairAmountTextBox.Text, out int PAIRAMOUNT) == false)//only accepts numbers
            {
                pairAmountTextBox.Text = "";
            }
            else if (Convert.ToInt16(pairAmountTextBox.Text) < 2 || Convert.ToInt16(pairAmountTextBox.Text) > 10)
            {
                pairErrorLabel.Show();
                singleplayerStart.Enabled = false;
                multiplayerStart.Enabled = false;
            }
            else
            {
                pairErrorLabel.Hide();
                singleplayerStart.Enabled = true;
                multiplayerStart.Enabled = true;
            }
        }

        //Called when changing difficulty in singleplayer
        private void difficulty_CheckedChanged(object sender, EventArgs e)
        {
            var diff = (RadioButton)sender;
            switch (diff.Name)
            {
                case "difficultyGoldfish":
                    AIDifficulty = 0;
                    player2Label.Text = "Goldfish";
                    break;
                case "difficultyEasy":
                    AIDifficulty = 1;
                    player2Label.Text = "Baby Bot";
                    break;
                case "difficultyMedium":
                    AIDifficulty = 2;
                    player2Label.Text = "Rusty Robot";
                    break;
                case "difficultyMedium2":
                    AIDifficulty = 3;
                    player2Label.Text = "Middling Machine";
                    break;
                case "difficultyMedium3":
                    AIDifficulty = 4;
                    player2Label.Text = "Danger Droid";
                    break;
                case "difficultyHard":
                    AIDifficulty = 5;
                    player2Label.Text = "Cheatyface";
                    break;
            }
        }

        //Called when card front radiobuttons checked changed in singleplayer menu or options. Changes the p1Front
        //variable that decides which image the IENumerable cardFronts returns when assigning card fronts
        private void changeFront(object sender, EventArgs e)
        {
            //saves the p1Front variable to the corresponding user selection.
            var front = (RadioButton)sender;
            switch (front.TabIndex)
            {
                case 0:
                    p1Front = 0;
                    frontPreview.Image = Properties.Resources.image3;
                    break;
                case 1:
                    p1Front = 1;
                    frontPreview.Image = Properties.Resources.hearts1;
                    break;
                case 2:
                    p1Front = 2;
                    frontPreview.Image = Properties.Resources.guilds4;
                    break;
                case 3:
                    p1Front = 3;
                    frontPreview.Image = Properties.Resources.fancyGuilds2;
                    break;
                case 4:
                    p1Front = 4;
                    frontPreview.Image = Properties.Resources.arcana1XIII;
                    break;
            }
            if (p1Front == p1Back && (p1Front == 1 || p1Front == 4))
                matchingBox.Enabled = true;
            //if back and front selected are both either Poker or Arcana, you can check a checkbox so the randomized front
            //will have a corresponding art for the backside, rather than random
            else
            {
                matchingBox.Enabled = false;
                matchingBox.Checked = false;
            }
            SaveProfile();
        }

        //called when back radiobuttons checked changed ins singleplayer menu or options. Changes the p1Back variable
        //that decides which image to use for card backs
        private void changeBack(object sender, EventArgs e)
        {
            var back = (RadioButton)sender;
            switch (back.TabIndex)
            {
                case 0:
                    p1Back = 0;
                    backPreview.Image = Properties.Resources.hamletti;
                    break;
                case 1:
                    p1Back = 1;
                    backPreview.Image = Properties.Resources.pokerBackRed;
                    break;
                case 2:
                    p1Back = 2;
                    backPreview.Image = Properties.Resources.guildsBack;
                    break;
                case 3:
                    p1Back = 3;
                    backPreview.Image = Properties.Resources.fancyGuildsBack;
                    break;
                case 4:
                    p1Back = 4;
                    backPreview.Image = Properties.Resources.arcanaBack1;
                    break;
            }
            if (p1Front == p1Back && (p1Front == 1 || p1Front == 4))
                matchingBox.Enabled = true;
            else
            {
                matchingBox.Enabled = false;
                matchingBox.Checked = false;
            }
            SaveProfile();
        }

        //change front art for multiplayer, note the lack of call for SaveProfile function, so changing settings in
        //multiplayer doesn't change singleplayer profile preferences
        private void changeFrontMulti(object sender, EventArgs e)
        {
            var front = (RadioButton)sender;
            switch (front.TabIndex)
            {
                case 0:
                    p1Front = 0;
                    break;
                case 1:
                    p1Front = 1;
                    break;
                case 2:
                    p1Front = 2;
                    break;
                case 3:
                    p1Front = 3;
                    break;
                case 4:
                    p1Front = 4;
                    break;
            }
            if (p1Front == p1Back && (p1Front == 1 || p1Front == 4))
                matchingBox.Enabled = true;
            else
            {
                matchingBox.Enabled = false;
                matchingBox.Checked = false;
            }
        }

        //change back art for multiplayer, same functionality as front side multiplayer
        private void changeBackMulti(object sender, EventArgs e)
        {
            var back = (RadioButton)sender;
            switch (back.TabIndex)
            {
                case 0:
                    p1Back = 0;
                    break;
                case 1:
                    p1Back = 1;
                    break;
                case 2:
                    p1Back = 2;
                    break;
                case 3:
                    p1Back = 3;
                    break;
                case 4:
                    p1Back = 4;
                    break;
            }
            if (p1Front == p1Back && (p1Front == 1 || p1Front == 4))
                matchingBox.Enabled = true;
            else
            {
                matchingBox.Enabled = false;
                matchingBox.Checked = false;
            }
        }

        //When starting a multiplayer game
        private void multiplayerStart_Click(object sender, EventArgs e)
        {
            //Removes and creates events to the replay button that pops up after a game
            //single and multiplayer has different handling for the button
            replayButton.Click -= new EventHandler(multiplayerStart_Click);
            replayButton.Click -= new EventHandler(singleplayerStart_Click);
            replayButton.Click += new EventHandler(multiplayerStart_Click);
            replayButton.Visible = false;
            //Button doesn't work if no players selected or names are the same. Button should be grayed out. Old solution
            //Most likely free to comment this line
            if ((player1Name.Text == player2Name.Text) || (player1Name.Text == "") || (player2Name.Text == ""))
                return;
            gamePanel.Show();
            player1Label.Text = player1Name.Text;
            player2Label.Text = player2Name.Text;
            singleplayer = false;
            //Randomize starting player
            int startingPlayer = rng.Next(2);
            if (startingPlayer == 0)
            {
                turnLabel.Text = player1Label.Text + "'s turn";
                player1turn = true;
            }
            else if (startingPlayer == 1)
            {
                turnLabel.Text = player2Label.Text + "'s turn";
                player1turn = false;
            }
            BuildBoard();
        }

        //When starting a singleplayer game
        private void singleplayerStart_Click(object sender, EventArgs e)
        {
            //Removes and creates events to the replay button that pops up after a game
            //single and multiplayer has different handling for the button
            replayButton.Click -= new EventHandler(multiplayerStart_Click);
            replayButton.Click -= new EventHandler(singleplayerStart_Click);
            replayButton.Click += new EventHandler(singleplayerStart_Click);
            replayButton.Visible = false;
            //Button doesn't work if no players selected or names are the same. Button should be grayed out. Old solution
            //Most likely free to comment this line
            if (profileNameLabel.Text == "")
                return;
            gamePanel.Show();
            player1Label.Text = p1Name;
            singleplayer = true;
            turnLabel.Text = player1Label.Text + "'s turn";
            BuildBoard();
        }

        //Shared code for both single and multiplayer for starting the game
        private void BuildBoard()
        {
            //Takes the correct art for card back, depending on user choice
            assignBack();
            //Resizes the table depending on user choice of pair amount
            ResizeTable(Convert.ToInt16(pairAmountTextBox.Text));
            //Randomize front images
            int counter = 0;
            firstClick = null;
            //This loop takes a random card in the gameLayoutPanel with an empty Tag value and assigns the next Image
            //in the IENumerable cardFronts collection there.
            foreach (var cardFront in cardFronts)
            {
                if (counter == cards.Length)//cards is a PixtureBox type array which holds all pictureboxes on the game board
                    break;
                //assignFront returns a random cards array member with an empty Tag property
                assignFront().Tag = cardFront; //Card's front image is stored in the picturebox' Tag property
                assignFront().Tag = cardFront; //2 Cards share the same front
                counter = counter + 2;
            }
            foreach (PictureBox Card in cards)
            {
                Card.Click -= new EventHandler(cardClick); //Flush click event from cards that might exist from earlier games
                Card.Click += new EventHandler(cardClick); //Create click event for all cards
                Card.Image = (Image)Properties.Resources.ResourceManager.GetObject(DEFAULTBACK); //Set back image for cards
            }
            //int type variables p1Score and p2Score track how many points each player has
            p1Score = 0;
            p2Score = 0;
            player1Score.Text = p1Score.ToString();
            player2Score.Text = p2Score.ToString();
            pregamePanel.Hide();
            yourTurn = true;
        }

        //Takes the correct art for card back, depending on user choice
        private void assignBack()
        {
            int random;
            //int type variable p1Back is used to choose the correct card back. Changing the radiobuttons in the menus
            //changes this variable. If you change the profile's .txt file you can choose whichever to use in singleplayer
            //without unlocking. Poker and Arcana styles have 2 different styles which are chosen randomly.
            switch (p1Back)
            {
                case 0:
                    DEFAULTBACK = "hamletti";
                    break;
                case 1:
                    random = rng.Next(0, 2);
                    if (random == 0)
                        DEFAULTBACK = "pokerBackRed";
                    else
                        DEFAULTBACK = "pokerBackBlue";
                    break;
                case 2:
                    DEFAULTBACK = "guildsBack";
                    break;
                case 3:
                    DEFAULTBACK = "fancyGuildsBack";
                    break;
                case 4:
                    random = rng.Next(0, 2);
                    if (random == 0)
                        DEFAULTBACK = "arcanaBack1";
                    else
                        DEFAULTBACK = "arcanaBack2";
                    break;

            }

        }

        //Randomizes front images 
        private PictureBox assignFront()
        {
            int num;
            do
            {
                num = rng.Next(0, cards.Length);//Takes a random card
            } while (cards[num].Tag != null);//Checks if the random card has an empty Tag
            return cards[num];//Returns the card position in the cards array so the image can be stored in it's Tag
        }

        //Resizes the gameLayoutPanel, which is used to display the game cards
        private void ResizeTable(int cardAmount)
        {
            //Flush the old controls
            gameLayoutPanel.Controls.Clear();
            Array.Resize(ref cards, Convert.ToInt16(pairAmountTextBox.Text) * 2);
            int rowCount = 0;
            int columnCount = 0;
            switch (cardAmount)//sets correct row and column count for chosen amount of pairs. Pretty inelegant solution
            {
                case 2:
                    rowCount = 2;
                    columnCount = 2;
                    break;
                case 3:
                    rowCount = 2;
                    columnCount = 3;
                    break;
                case 4:
                    rowCount = 2;
                    columnCount = 4;
                    break;
                case 5:
                    rowCount = 2;
                    columnCount = 5;
                    break;
                case 6:
                    rowCount = 3;
                    columnCount = 4;
                    break;
                case 7:
                    rowCount = 3;
                    columnCount = 5;
                    break;
                case 8:
                    rowCount = 4;
                    columnCount = 4;
                    break;
                case 9:
                    rowCount = 5;
                    columnCount = 5;
                    break;
                case 10:
                    rowCount = 5;
                    columnCount = 5;
                    break;
                default:
                    break;
            }
            gameLayoutPanel.ColumnCount = columnCount;
            gameLayoutPanel.RowCount = rowCount;
            int arrayCounter = 0;
            for (int row = 0; row < rowCount; row++)
            {
                for (int col = 0; col < columnCount; col++)
                {
                    PictureBox newCard = CreateCard();
                    cards[arrayCounter] = newCard;//Newly created card is placed in the cards array, so the images can be assigned easily
                    gameLayoutPanel.Controls.Add(newCard, col, row);//The picturebox is placed on the panel here
                    arrayCounter++;
                    if (arrayCounter == cards.Length)
                        return;
                }
            }

        }

        //Creates new cards
        private PictureBox CreateCard()
        {
            PictureBox card = new PictureBox()
            {
                SizeMode = PictureBoxSizeMode.StretchImage,
                Size = new Size(100, 150),
                Tag = null,
                Visible = true,
                BackColor = Color.Green//BackColor variable is used by AI as "memory" whether they've seen the card or not
            };
            return card;
        }

        //Reads profile info of currently selected profile and stores the data in variables
        private void ReadScore()
        {
            Int32.TryParse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + p1Name + ".txt").Skip(1).Take(1).First(), out p1Wins);
            Int32.TryParse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + p1Name + ".txt").Skip(3).Take(1).First(), out p1Losses);
            Int32.TryParse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + p1Name + ".txt").Skip(5).Take(1).First(), out p1Streak);
            Int32.TryParse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + p1Name + ".txt").Skip(7).Take(1).First(), out p1Xp);
            Int32.TryParse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + p1Name + ".txt").Skip(9).Take(1).First(), out p1Back);
            Int32.TryParse(File.ReadLines(appPath + "\\MemoryGameProfiles\\" + p1Name + ".txt").Skip(11).Take(1).First(), out p1Front);
            //Grays out options where the current profile isnt high enough level
            //XP requirement is stored in the radiobutton's Tag property. You gain one level for every 10 XP.
            foreach (RadioButton button in frontGroup.Controls)
            {
                button.Enabled = true;
                if (p1Xp < Convert.ToInt16(button.Tag))
                {
                    button.Text = "Requires Level " + Convert.ToInt16(button.Tag) / 10;
                    button.Enabled = false;
                }
                //Checks the same option that was last used, according to the .txt file
                if (button.TabIndex == p1Front)
                {
                    button.Checked = true;
                }
            }
            //Same thing as above but replicated to the singleplayer pregame options
            foreach (RadioButton button in singleFrontGroup.Controls)
            {
                button.Enabled = true;
                if (p1Xp < Convert.ToInt16(button.Tag))
                {
                    button.Text = "Requires Level " + Convert.ToInt16(button.Tag) / 10;
                    button.Enabled = false;
                }
                if (button.TabIndex == p1Front)
                {
                    button.Checked = true;
                }
            }
            //Now the same thing for cardback image
            foreach (RadioButton button in backGroup.Controls)
            {
                button.Enabled = true;
                if (p1Xp < Convert.ToInt16(button.Tag))
                {
                    button.Text = "Requires Level " + Convert.ToInt16(button.Tag) / 10;
                    button.Enabled = false;
                }
                if (button.TabIndex == p1Back)
                {
                    button.Checked = true;
                }
            }
            //And again for cardback in singleplayer pregame options
            foreach (RadioButton button in singleBackGroup.Controls)
            {
                button.Enabled = true;
                if (p1Xp < Convert.ToInt16(button.Tag))
                {
                    button.Text = "Requires Level " + Convert.ToInt16(button.Tag) / 10;
                    button.Enabled = false;
                }
                if (button.TabIndex == p1Back)
                {
                    button.Checked = true;
                }
            }
        }

        //When clicking "create profile" in singleplayer pregame menu
        private void singleNewProfileButton_Click(object sender, EventArgs e)
        {
            //Doesn't accept duplicate names
            if (singleProfileList.Items.Contains(singleNewProfileTextBox.Text) == false && singleNewProfileTextBox.Text != "CreateProfile" && singleNewProfileTextBox.Text != "")
            {
                CreateProfile(singleNewProfileTextBox);
            }
        }

        //When clicking "create profile" in multiplayer pregame menu
        private void multiNewProfileButton_Click(object sender, EventArgs e)
        {
            if (singleProfileList.Items.Contains(multiNewProfileTextBox.Text) == false && multiNewProfileTextBox.Text != "CreateProfile" && multiNewProfileTextBox.Text != "")
            {
                CreateProfile(multiNewProfileTextBox);
            }
        }

        //When clicking "create profile" in options menu
        private void optionsNewProfileButton_Click(object sender, EventArgs e)
        {
            if (singleProfileList.Items.Contains(optionsNewProfileTextBox.Text) == false && optionsNewProfileTextBox.Text != "CreateProfile" && optionsNewProfileTextBox.Text != "")
            {
                CreateProfile(optionsNewProfileTextBox);
            }
        }

        //Creates new profile and a .txt file associated with that profile
        private void CreateProfile(TextBox name)
        {
            Directory.CreateDirectory(appPath + "\\MemoryGameProfiles");
            FileStream myFS = new FileStream(appPath + "\\MemoryGameProfiles\\" + name.Text + ".txt", FileMode.Create, FileAccess.Write);
            using (StreamWriter mySW = new StreamWriter(myFS))
            {
                mySW.WriteLine("Wins:");
                mySW.WriteLine("0");
                mySW.WriteLine("Losses:");
                mySW.WriteLine("0");
                mySW.WriteLine("Streak:");
                mySW.WriteLine("0");
                mySW.WriteLine("XP:");
                mySW.WriteLine("0");
                mySW.WriteLine("Card Back:");
                mySW.WriteLine("0");
                mySW.WriteLine("Card Front:");
                mySW.WriteLine("0");
            }
            //Populates profile lists with all profiles in the directory
            DirectoryInfo profileDirectory = new DirectoryInfo(appPath + "\\MemoryGameProfiles\\");
            FileInfo[] profileFiles = profileDirectory.GetFiles();
            singleProfileList.Items.Add(name.Text);
            multiProfileList1.Items.Add(name.Text);
            multiProfileList2.Items.Add(name.Text);
            profileBox.Items.Add(name.Text);
        }
        
        //When you change active profile in singleplayer menu
        private void singleProfileList_SelectedIndexChanged(object sender, EventArgs e)
        {
            p1Name = singleProfileList.GetItemText(singleProfileList.SelectedItem);
            profileBox.Text = p1Name;
            profileNameLabel.Text = p1Name;
            deleteButton.Enabled = true;
            //Sets the correct names for radiobuttons that control back and front images
            //If selected profile is not high enough level, they will be hidden later
            SetArtNames();
            //ReadScore hides selections that are too high level, and stores wins, losses, streak, xp, back and front variables
            ReadScore();
            //shows the current profile's data
            singleWins.Text =   "Wins   : " + p1Wins;
            singleLosses.Text = "Losses: " + p1Losses;
            singleStreak.Text = "Streak : " + p1Streak;
            singleXp.Text =     "Level   : " + p1Xp/10;
            xpBar.Value = p1Xp % 10;
            optionsWins.Text = "Wins   : " + p1Wins;
            optionsLosses.Text = "Losses: " + p1Losses;
            optionsStreak.Text = "Streak : " + p1Streak;
            optionsLevel.Text = "Level   : " + p1Xp / 10;
            optionsXpBar.Value = p1Xp % 10;
            //Hides error message that tells user to select a profile
            singleplayerProfileError.Hide();
        }

        //Sets the correct texts for card front and back image selection in singleplayer and options menu
        //changed if selected profile is too low level
        private void SetArtNames()
        {
            pokerFront.Text = "Poker";
            guildsFront.Text = "Guilds";
            fancyGuildsFront.Text = "Stylish Guilds";
            arcanaFront.Text = "Arcana";

            pokerBack.Text = "Poker";
            guildsBack.Text = "Guilds";
            fancyGuildsBack.Text = "Stylish Guilds";
            arcanaBack.Text = "Arcana";

            singlePokerFront.Text = "Poker";
            singleGuildsFront.Text = "Guilds";
            singleFancyGuildsFront.Text = "Stylish Guilds";
            singleArcanaFront.Text = "Arcana";

            singlePokerBack.Text = "Poker";
            singleGuildsBack.Text = "Guilds";
            singleFancyGuildsBack.Text = "Stylish Guilds";
            singleArcanaBack.Text = "Arcana";
        }

        //When you change active profile in options menu
        private void profileBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            singleProfileList.SelectedItem = profileBox.SelectedItem;//changes active profile in singleplayer pregame menu
        }
        
        //When you select a profile for player 2 in multiplayer
        private void multiProfileList2_Click(object sender, EventArgs e)
        {
            player2Name.Text = multiProfileList2.GetItemText(multiProfileList2.SelectedItem);
            if ((player2Name.Text != player1Name.Text) && (player1Name.Text != ""))
            {
                multiplayerStart.Enabled = true;
                multiplayerProfilesError.Hide();
            }
            //Game wont start if same profiles selected for p1&p2 or if either is empty
            else
            {
                multiplayerStart.Enabled = false;
                multiplayerProfilesError.Show();
            }
        }

        //When you select a profile for player 1 in multiplayer
        private void multiProfileList1_Click(object sender, EventArgs e)
        {
            player1Name.Text = multiProfileList1.GetItemText(multiProfileList1.SelectedItem);
            if ((player2Name.Text != player1Name.Text) && (player2Name.Text != ""))
            {
                multiplayerStart.Enabled = true;
                multiplayerProfilesError.Hide();
            }
            else
            {
                multiplayerStart.Enabled = false;
                multiplayerProfilesError.Show();
            }
        }

        //Called when a property of the profile is changed, so when you change card preferences or on game end.
        //Saves new data on the profile's .txt file
        private void SaveProfile()
        {
            FileStream myFS = new FileStream(appPath + "\\MemoryGameProfiles\\" + p1Name + ".txt", FileMode.Open, FileAccess.Write);
            using (StreamWriter mySW = new StreamWriter(myFS))
            {
                mySW.WriteLine("Wins:");
                mySW.WriteLine(p1Wins);
                mySW.WriteLine("Losses:");
                mySW.WriteLine(p1Losses);
                mySW.WriteLine("Streak:");
                mySW.WriteLine(p1Streak);
                mySW.WriteLine("XP:");
                mySW.WriteLine(p1Xp);
                mySW.WriteLine("Card Back:");
                mySW.WriteLine(p1Back);
                mySW.WriteLine("Card Front:");
                mySW.WriteLine(p1Front);
            }
        }

        //Called whenever you click a card
        private void cardClick(object sender, EventArgs e)
        {
            if (yourTurn == false)//Can't click if not your turn
                return;

            if (firstClick == sender)//Can't click same card twice
                return;

            var card = (PictureBox)sender;
            if (AIDifficulty > 1)//Easy AI doesn't see what you open
            {
                card.BackColor = Color.Blue;//Blue backcolor signifies what AI has seen
            }

            if (firstClick == null)//first card opened is stored here
            {
                firstClick = card;
                //the image is changed from the default back image to the card's tag which is the card's front
                card.Image = (Image)card.Tag;
                return;
            }

            card.Image = (Image)card.Tag;//second card

            if (card.Image == firstClick.Image && card != firstClick) //same cards
            {
                card.Visible =  false;
                firstClick.Visible = false;
                card.BackColor = Color.Red;
                firstClick.BackColor = Color.Red;
                if (singleplayer || player1turn)
                {
                    p1Score++;
                    player1Score.Text = p1Score.ToString();
                }
                else//if multiplayer and p2 turn, give points to player 2
                {
                    p2Score++;
                    player2Score.Text = p2Score.ToString();
                }
            }
            else //wrong cards
            {
                yourTurn = false;
                if (player1turn && !singleplayer)
                    player1turn = false;
                else if (!player1turn && !singleplayer)
                    player1turn = true;
                clickDelay.Start();
                //When clickDelay timer ticks, cards will be flipped back
            }
            firstClick = null;
            //if there are any cards still on the board, the function doesn't continue
            if (cards.Any(p => p.Visible)) return;

            GameEnd();
        }

        //Delay after player gets 2 wrong
        private void ClickDelay_Tick(object sender, EventArgs e)
        {
            Clean();
            clickDelay.Stop();
            if (singleplayer)//give AI the turn in singleplayer
                ComputerTurn();
            else if (player1turn)
            {
                turnLabel.Text = player1Label.Text + "'s turn";
                yourTurn = true;
            }
            else
            {
                turnLabel.Text = player2Label.Text + "'s turn";
                yourTurn = true;
            }
        }
        
        //Called when player chooses cards which dont share the same front
        private void Clean()
        {
            foreach (PictureBox card in cards)//Flips cards back to facedown
            {
                card.Image = (Image)Properties.Resources.ResourceManager.GetObject(DEFAULTBACK);
            }
        }

        //AI's turn
        private void ComputerTurn()
        {
            turnLabel.Text = player2Label.Text + "'s turn";
            bool success = false;
            if (cards.Any(p => p.Visible))//if there are cards on the board
            {
                //Takes a pair that has both pictures known, easies´t difficulty doesn't take known cards into account
                if (AIDifficulty > 0)
                    success = AlreadyKnown();

                //Takes a random card, checks if pair is known. if not, checks if a random card is pair
                //only accessed if AI didn't find a pair in AlreadyKnown function
                if (success == false)
                {
                    success = FirstUnknown();
                }
            }
            else
            {
                GameEnd();
            }
        }

        private bool AlreadyKnown()
        {
            foreach (PictureBox firstCard in cards)//check all cards on board
            {
                if (firstCard.BackColor == Color.Blue)//if a card's front image is known by the AI
                {
                    foreach (PictureBox secondCard in cards)//check all cards on board again
                    {
                        //if first and second card have the same front image, they are not the same card and second card is known
                        if (firstCard.Tag == secondCard.Tag && firstCard != secondCard && secondCard.BackColor == Color.Blue)
                        {
                            int AIforgets = rng.Next(0, 100);
                            //Easier difficulties will perform a "memory check". If they fail, they'll forget known cards
                            if (AIforgets > 50 && AIDifficulty == 2)
                            {
                                firstCard.BackColor = Color.Green;
                                secondCard.BackColor = Color.Green;
                                return false;
                            }
                            if (AIforgets > 65 && (AIDifficulty == 1 || AIDifficulty == 3))
                            {
                                firstCard.BackColor = Color.Green;
                                secondCard.BackColor = Color.Green;
                                return false;
                            }
                            if (AIforgets > 80 && AIDifficulty == 4)
                            {
                                firstCard.BackColor = Color.Green;
                                secondCard.BackColor = Color.Green;
                                return false;
                            }
                            //MessageBox.Show("Both known");
                            if (AIDifficulty < 5)//hard difficulty doesn't reveal cards to player
                            {
                                firstCard.Image = (Image)firstCard.Tag;
                                secondCard.Image = (Image)secondCard.Tag;
                            }
                            p2Score++;
                            player2Score.Text = p2Score.ToString();
                            firstCard.BackColor = Color.Red;
                            secondCard.BackColor = Color.Red;
                            computerDelay.Start();
                            return true;//returns true value for 'success' variable, so AI won't try to guess a pair
                        }
                    }
                }
            }
            return false;//returns false value for 'success' variable if AI didn't know an existing pair
        }

        private bool FirstUnknown()
        {
            int i = 0;

            do //take random card
            {
                i = rng.Next(cards.Length);
            } while (cards[i].BackColor != Color.Green);
            //wont return cards with blue backcolor(known by AI, but not collected) or red backcolor(collected)
            //check if pair of earlier card is known
            foreach (PictureBox secondCard in cards)
            {
                //if first and second card have the same front image, they are not the same card and second card is known
                if (cards[i].Tag == secondCard.Tag && cards[i] != secondCard && secondCard.BackColor == Color.Blue)
                {
                    int AIforgets = rng.Next(0, 100);
                    if (AIforgets > 50 && AIDifficulty == 2)
                    {
                        secondCard.BackColor = Color.Green;
                        continue;
                    }
                    if (AIforgets > 65 && (AIDifficulty == 1 || AIDifficulty == 3))
                    {
                        secondCard.BackColor = Color.Green;
                        continue;
                    }
                    if (AIforgets > 80 && AIDifficulty == 4)
                    {
                        secondCard.BackColor = Color.Green;
                        continue;
                    }
                    //MessageBox.Show("Randomly found first that was same as known");
                    if (AIDifficulty < 5)//hard doesn't reveal cards to player
                    {
                        cards[i].Image = (Image)cards[i].Tag;
                        secondCard.Image = (Image)secondCard.Tag;
                    }
                    p2Score++;
                    player2Score.Text = p2Score.ToString();
                    cards[i].BackColor = Color.Red;
                    secondCard.BackColor = Color.Red;
                    computerDelay.Start();
                    return true;//leave function if AI found a pair
                }
            }

            int j = 0;

            do //takes another random card
            {
                j = rng.Next(cards.Length);
            } while (cards[j].BackColor != Color.Green || i == j);
            //first card can't be same as second card and AI can't know of either
            if (cards[i].Tag == cards[j].Tag)//if random cards match
            {
                //MessageBox.Show("Got lucky");
                if (AIDifficulty < 5)//hard doesn't reveal cards
                {
                    cards[i].Image = (Image)cards[i].Tag;
                    cards[j].Image = (Image)cards[j].Tag;
                }
                p2Score++;
                player2Score.Text = p2Score.ToString();
                cards[i].BackColor = Color.Red;
                cards[j].BackColor = Color.Red;
                computerDelay.Start();
                return true;//leave function when found a pair
            }
            else//computer failed
            {
                if (AIDifficulty != 0)
                {
                    cards[i].BackColor = Color.Blue;
                    cards[j].BackColor = Color.Blue;
                }
                //MessageBox.Show("Not Lucky");
                if (AIDifficulty < 5)
                {
                    cards[i].Image = (Image)cards[i].Tag;
                    cards[j].Image = (Image)cards[j].Tag;
                }
                computerFail.Start();//computerFail timer gives more time to look at cards AI flipped than when AI succeeds
            return false;
            }
        }

        //Timer when AI gets 2 right
        private void ComputerDelay_Tick(object sender, EventArgs e)
        {
            ComputerClean();
            computerDelay.Stop();
            ComputerTurn();
        }

        //Timer when AI guesses wrong
        private void ComputerFail_Tick(object sender, EventArgs e)
        {
            Clean();
            turnLabel.Text = player1Label.Text + "'s turn";
            yourTurn = true;
            computerFail.Stop();
        }

        //Called when AI gets correct cards
        private void ComputerClean()
        {
            foreach (PictureBox card in cards)
            {
                if (card.BackColor == Color.Red)//Red BackColor is assigned when card should no longer be visible
                {
                    card.Visible = false;
                }
            }
        }

        //Called when all cards are flipped over
        private void GameEnd()
        {
            //in singleplayer, saves profile progress
            if (singleplayer)
            {
                if (p2Score > p1Score)//Loss
                {
                    MessageBox.Show("You lose");
                    p1Losses++;
                    p1Streak = 0;
                }
                else if (p2Score < p1Score)//Win
                {
                    p1Wins++;
                    p1Streak++;
                    int xpBefore = p1Xp;
                    //Different difficulties give differing amount of xp
                    if (AIDifficulty == 1)
                        p1Xp += 1 + (p1Streak / 2);
                    else if (AIDifficulty > 1 && AIDifficulty < 5)
                        p1Xp += 2 + p1Streak;
                    else if (AIDifficulty == 5)
                        p1Xp += 4 + (p1Streak * 3 / 2);
                    if (xpBefore / 10 != p1Xp / 10)
                        MessageBox.Show("You win and reached level " + p1Xp / 10);
                    else
                        MessageBox.Show("You win");
                }
                else//Tie
                    MessageBox.Show("Tie");
                //Refresh info in pregame panel and options 
                singleWins.Text = "Wins   : " + p1Wins;
                singleLosses.Text = "Losses: " + p1Losses;
                singleStreak.Text = "Streak : " + p1Streak;
                singleXp.Text = "Level   : " + p1Xp / 10;
                xpBar.Value = p1Xp % 10;
                optionsWins.Text = "Wins   : " + p1Wins;
                optionsLosses.Text = "Losses: " + p1Losses;
                optionsStreak.Text = "Streak : " + p1Streak;
                optionsLevel.Text = "Level   : " + p1Xp / 10;
                optionsXpBar.Value = p1Xp % 10;
                //Save profile in the .txt
                SaveProfile();
            }
            else//multiplayer just checks which player has higher score
            {
                if (p2Score > p1Score)
                    MessageBox.Show(player2Label.Text + " Wins");
                else if (p2Score < p1Score)
                    MessageBox.Show(player1Label.Text + " Wins");
                else
                    MessageBox.Show("Tie");
            }
            replayButton.Visible = true;
        }

        //return button in the game screen returns the user to pregame settings
        private void returnButton_Click(object sender, EventArgs e)
        {
            pregamePanel.Show();
            if (singleplayer)
            {
                SetArtNames();
                ReadScore();
            }
            gamePanel.Hide();
        }

        //main menu button in game screen returns the user to main menu
        private void menuButton_Click(object sender, EventArgs e)
        {
            pregamePanel.Hide();
            gamePanel.Hide();
            sharedPanel.Visible = false;
            if (singleplayer && p1Name != "")
            {
                SetArtNames();
                ReadScore();
            }
            pregameSingleOptions.Hide();
            pregameMultiOptions.Hide();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (profileBox.Items.Count == 1)
            {
                MessageBox.Show("Can't delete last profile", "Error");
                return;
            }
            if (MessageBox.Show("Permanently delete profile?", "Delete Profile", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                File.Delete(appPath + "\\MemoryGameProfiles\\" + p1Name + ".txt");
                GetProfiles();
                profileBox.SelectedIndex = 0;
                ReadScore();
            }
        }
    }
}
