﻿namespace UIP_Project
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.leaderboardsButton = new System.Windows.Forms.Button();
            this.optionsButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.optionsPanel = new System.Windows.Forms.Panel();
            this.backPreview = new System.Windows.Forms.PictureBox();
            this.frontPreview = new System.Windows.Forms.PictureBox();
            this.deleteButton = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.optionsXpBar = new System.Windows.Forms.ProgressBar();
            this.optionsLevel = new System.Windows.Forms.Label();
            this.optionsStreak = new System.Windows.Forms.Label();
            this.optionsLosses = new System.Windows.Forms.Label();
            this.optionsWins = new System.Windows.Forms.Label();
            this.backGroup = new System.Windows.Forms.GroupBox();
            this.fancyGuildsBack = new System.Windows.Forms.RadioButton();
            this.guildsBack = new System.Windows.Forms.RadioButton();
            this.arcanaBack = new System.Windows.Forms.RadioButton();
            this.pokerBack = new System.Windows.Forms.RadioButton();
            this.defBack = new System.Windows.Forms.RadioButton();
            this.frontGroup = new System.Windows.Forms.GroupBox();
            this.fancyGuildsFront = new System.Windows.Forms.RadioButton();
            this.guildsFront = new System.Windows.Forms.RadioButton();
            this.arcanaFront = new System.Windows.Forms.RadioButton();
            this.pokerFront = new System.Windows.Forms.RadioButton();
            this.defaultFront = new System.Windows.Forms.RadioButton();
            this.optionsNewProfileTextBox = new System.Windows.Forms.TextBox();
            this.optionsNewProfileButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.profileBox = new System.Windows.Forms.ComboBox();
            this.optionsExitButton = new System.Windows.Forms.Button();
            this.pregamePanel = new System.Windows.Forms.Panel();
            this.backButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.multiplayerButton = new System.Windows.Forms.Button();
            this.singleplayerButton = new System.Windows.Forms.Button();
            this.pregameMultiOptions = new System.Windows.Forms.Panel();
            this.multiplayerProfilesError = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.multiBackGuilds = new System.Windows.Forms.RadioButton();
            this.multiBackFancyGuilds = new System.Windows.Forms.RadioButton();
            this.multiBackArcana = new System.Windows.Forms.RadioButton();
            this.multiBackPoker = new System.Windows.Forms.RadioButton();
            this.multiBackDefault = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.multiFrontGuilds = new System.Windows.Forms.RadioButton();
            this.multiFrontFancyGuilds = new System.Windows.Forms.RadioButton();
            this.multiFrontArcana = new System.Windows.Forms.RadioButton();
            this.multiFrontPoker = new System.Windows.Forms.RadioButton();
            this.multiFrontDefault = new System.Windows.Forms.RadioButton();
            this.player2Name = new System.Windows.Forms.Label();
            this.player1Name = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.multiProfileList2 = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.multiNewProfileTextBox = new System.Windows.Forms.TextBox();
            this.multiNewProfileButton = new System.Windows.Forms.Button();
            this.multiProfileList1 = new System.Windows.Forms.ListBox();
            this.multiplayerStart = new System.Windows.Forms.Button();
            this.pregameSingleOptions = new System.Windows.Forms.Panel();
            this.singleplayerProfileError = new System.Windows.Forms.Label();
            this.singleBackGroup = new System.Windows.Forms.GroupBox();
            this.singleFancyGuildsBack = new System.Windows.Forms.RadioButton();
            this.singleGuildsBack = new System.Windows.Forms.RadioButton();
            this.singleArcanaBack = new System.Windows.Forms.RadioButton();
            this.singlePokerBack = new System.Windows.Forms.RadioButton();
            this.singledefaultBack = new System.Windows.Forms.RadioButton();
            this.singleFrontGroup = new System.Windows.Forms.GroupBox();
            this.singleFancyGuildsFront = new System.Windows.Forms.RadioButton();
            this.singleGuildsFront = new System.Windows.Forms.RadioButton();
            this.singleArcanaFront = new System.Windows.Forms.RadioButton();
            this.singlePokerFront = new System.Windows.Forms.RadioButton();
            this.singleDefaultFront = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.xpBar = new System.Windows.Forms.ProgressBar();
            this.singleXp = new System.Windows.Forms.Label();
            this.singleStreak = new System.Windows.Forms.Label();
            this.singleLosses = new System.Windows.Forms.Label();
            this.singleWins = new System.Windows.Forms.Label();
            this.singleProfileList = new System.Windows.Forms.ComboBox();
            this.singleNewProfileTextBox = new System.Windows.Forms.TextBox();
            this.profileNameLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.singleNewProfileButton = new System.Windows.Forms.Button();
            this.singleplayerStart = new System.Windows.Forms.Button();
            this.difficultyGroup = new System.Windows.Forms.GroupBox();
            this.difficultyPanel = new System.Windows.Forms.TableLayoutPanel();
            this.difficultyHard = new System.Windows.Forms.RadioButton();
            this.difficultyMedium2 = new System.Windows.Forms.RadioButton();
            this.difficultyGoldfish = new System.Windows.Forms.RadioButton();
            this.difficultyMedium = new System.Windows.Forms.RadioButton();
            this.difficultyEasy = new System.Windows.Forms.RadioButton();
            this.difficultyMedium3 = new System.Windows.Forms.RadioButton();
            this.sharedPanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.matchingBox = new System.Windows.Forms.CheckBox();
            this.pairAmountTextBox = new System.Windows.Forms.TextBox();
            this.pairErrorLabel = new System.Windows.Forms.Label();
            this.gamePanel = new System.Windows.Forms.Panel();
            this.player1Label = new System.Windows.Forms.Label();
            this.gameLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.card16 = new System.Windows.Forms.PictureBox();
            this.card15 = new System.Windows.Forms.PictureBox();
            this.card17 = new System.Windows.Forms.PictureBox();
            this.card19 = new System.Windows.Forms.PictureBox();
            this.card18 = new System.Windows.Forms.PictureBox();
            this.card11 = new System.Windows.Forms.PictureBox();
            this.card10 = new System.Windows.Forms.PictureBox();
            this.card12 = new System.Windows.Forms.PictureBox();
            this.card14 = new System.Windows.Forms.PictureBox();
            this.card13 = new System.Windows.Forms.PictureBox();
            this.card9 = new System.Windows.Forms.PictureBox();
            this.card7 = new System.Windows.Forms.PictureBox();
            this.card5 = new System.Windows.Forms.PictureBox();
            this.card3 = new System.Windows.Forms.PictureBox();
            this.card1 = new System.Windows.Forms.PictureBox();
            this.card8 = new System.Windows.Forms.PictureBox();
            this.card6 = new System.Windows.Forms.PictureBox();
            this.card4 = new System.Windows.Forms.PictureBox();
            this.card2 = new System.Windows.Forms.PictureBox();
            this.card0 = new System.Windows.Forms.PictureBox();
            this.replayButton = new System.Windows.Forms.Button();
            this.menuButton = new System.Windows.Forms.Button();
            this.returnButton = new System.Windows.Forms.Button();
            this.turnLabel = new System.Windows.Forms.Label();
            this.player2Score = new System.Windows.Forms.Label();
            this.player1Score = new System.Windows.Forms.Label();
            this.player2Label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.mainTitle = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.leaderboardsPanel = new System.Windows.Forms.Panel();
            this.leaderboardsTitle = new System.Windows.Forms.Label();
            this.leaderboardsBackButton = new System.Windows.Forms.Button();
            this.leaderboardsSubtitle = new System.Windows.Forms.Label();
            this.leaderboardsTable = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.optionsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.frontPreview)).BeginInit();
            this.backGroup.SuspendLayout();
            this.frontGroup.SuspendLayout();
            this.pregamePanel.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.pregameMultiOptions.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pregameSingleOptions.SuspendLayout();
            this.singleBackGroup.SuspendLayout();
            this.singleFrontGroup.SuspendLayout();
            this.difficultyGroup.SuspendLayout();
            this.difficultyPanel.SuspendLayout();
            this.sharedPanel.SuspendLayout();
            this.gamePanel.SuspendLayout();
            this.gameLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.card16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.card0)).BeginInit();
            this.leaderboardsPanel.SuspendLayout();
            this.leaderboardsTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.leaderboardsButton, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.optionsButton, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.startButton, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.exitButton, 0, 3);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(858, 172);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 331);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // leaderboardsButton
            // 
            this.leaderboardsButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.leaderboardsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.leaderboardsButton.Location = new System.Drawing.Point(3, 168);
            this.leaderboardsButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.leaderboardsButton.Name = "leaderboardsButton";
            this.leaderboardsButton.Size = new System.Drawing.Size(194, 74);
            this.leaderboardsButton.TabIndex = 3;
            this.leaderboardsButton.Text = "Leaderboards";
            this.leaderboardsButton.UseVisualStyleBackColor = false;
            this.leaderboardsButton.Click += new System.EventHandler(this.leaderboardsButton_Click);
            // 
            // optionsButton
            // 
            this.optionsButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.optionsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.optionsButton.Location = new System.Drawing.Point(3, 86);
            this.optionsButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.optionsButton.Name = "optionsButton";
            this.optionsButton.Size = new System.Drawing.Size(194, 74);
            this.optionsButton.TabIndex = 1;
            this.optionsButton.Text = "Options";
            this.optionsButton.UseVisualStyleBackColor = false;
            this.optionsButton.Click += new System.EventHandler(this.optionsButton_Click);
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.startButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.startButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.startButton.Location = new System.Drawing.Point(3, 4);
            this.startButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(194, 74);
            this.startButton.TabIndex = 0;
            this.startButton.Text = "New Game";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Location = new System.Drawing.Point(3, 250);
            this.exitButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(194, 77);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // optionsPanel
            // 
            this.optionsPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.optionsPanel.Controls.Add(this.backPreview);
            this.optionsPanel.Controls.Add(this.frontPreview);
            this.optionsPanel.Controls.Add(this.deleteButton);
            this.optionsPanel.Controls.Add(this.label16);
            this.optionsPanel.Controls.Add(this.label6);
            this.optionsPanel.Controls.Add(this.optionsXpBar);
            this.optionsPanel.Controls.Add(this.optionsLevel);
            this.optionsPanel.Controls.Add(this.optionsStreak);
            this.optionsPanel.Controls.Add(this.optionsLosses);
            this.optionsPanel.Controls.Add(this.optionsWins);
            this.optionsPanel.Controls.Add(this.backGroup);
            this.optionsPanel.Controls.Add(this.frontGroup);
            this.optionsPanel.Controls.Add(this.optionsNewProfileTextBox);
            this.optionsPanel.Controls.Add(this.optionsNewProfileButton);
            this.optionsPanel.Controls.Add(this.label1);
            this.optionsPanel.Controls.Add(this.profileBox);
            this.optionsPanel.Controls.Add(this.optionsExitButton);
            this.optionsPanel.Location = new System.Drawing.Point(448, 6);
            this.optionsPanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.optionsPanel.Name = "optionsPanel";
            this.optionsPanel.Size = new System.Drawing.Size(304, 717);
            this.optionsPanel.TabIndex = 1;
            this.optionsPanel.Visible = false;
            // 
            // backPreview
            // 
            this.backPreview.Location = new System.Drawing.Point(172, 506);
            this.backPreview.Name = "backPreview";
            this.backPreview.Size = new System.Drawing.Size(100, 156);
            this.backPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.backPreview.TabIndex = 6;
            this.backPreview.TabStop = false;
            // 
            // frontPreview
            // 
            this.frontPreview.Location = new System.Drawing.Point(172, 301);
            this.frontPreview.Name = "frontPreview";
            this.frontPreview.Size = new System.Drawing.Size(100, 156);
            this.frontPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.frontPreview.TabIndex = 5;
            this.frontPreview.TabStop = false;
            // 
            // deleteButton
            // 
            this.deleteButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.deleteButton.Enabled = false;
            this.deleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.deleteButton.Location = new System.Drawing.Point(197, 220);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(78, 49);
            this.deleteButton.TabIndex = 21;
            this.deleteButton.Text = "Delete Profile";
            this.deleteButton.UseVisualStyleBackColor = false;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Top;
            this.label16.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.Location = new System.Drawing.Point(0, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(304, 38);
            this.label16.TabIndex = 20;
            this.label16.Text = "Options";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(20, 249);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "Xp:";
            // 
            // optionsXpBar
            // 
            this.optionsXpBar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.optionsXpBar.ForeColor = System.Drawing.Color.Red;
            this.optionsXpBar.Location = new System.Drawing.Point(55, 253);
            this.optionsXpBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.optionsXpBar.Maximum = 10;
            this.optionsXpBar.Name = "optionsXpBar";
            this.optionsXpBar.Size = new System.Drawing.Size(134, 17);
            this.optionsXpBar.TabIndex = 18;
            // 
            // optionsLevel
            // 
            this.optionsLevel.AutoSize = true;
            this.optionsLevel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.optionsLevel.Location = new System.Drawing.Point(21, 229);
            this.optionsLevel.Name = "optionsLevel";
            this.optionsLevel.Size = new System.Drawing.Size(50, 20);
            this.optionsLevel.TabIndex = 17;
            this.optionsLevel.Text = "Level: ";
            // 
            // optionsStreak
            // 
            this.optionsStreak.AutoSize = true;
            this.optionsStreak.ForeColor = System.Drawing.SystemColors.ControlText;
            this.optionsStreak.Location = new System.Drawing.Point(21, 209);
            this.optionsStreak.Name = "optionsStreak";
            this.optionsStreak.Size = new System.Drawing.Size(58, 20);
            this.optionsStreak.TabIndex = 16;
            this.optionsStreak.Text = "Streak: ";
            // 
            // optionsLosses
            // 
            this.optionsLosses.AutoSize = true;
            this.optionsLosses.ForeColor = System.Drawing.SystemColors.ControlText;
            this.optionsLosses.Location = new System.Drawing.Point(21, 189);
            this.optionsLosses.Name = "optionsLosses";
            this.optionsLosses.Size = new System.Drawing.Size(58, 20);
            this.optionsLosses.TabIndex = 15;
            this.optionsLosses.Text = "Losses: ";
            // 
            // optionsWins
            // 
            this.optionsWins.AutoSize = true;
            this.optionsWins.ForeColor = System.Drawing.SystemColors.ControlText;
            this.optionsWins.Location = new System.Drawing.Point(21, 169);
            this.optionsWins.Name = "optionsWins";
            this.optionsWins.Size = new System.Drawing.Size(49, 20);
            this.optionsWins.TabIndex = 14;
            this.optionsWins.Text = "Wins: ";
            // 
            // backGroup
            // 
            this.backGroup.Controls.Add(this.fancyGuildsBack);
            this.backGroup.Controls.Add(this.guildsBack);
            this.backGroup.Controls.Add(this.arcanaBack);
            this.backGroup.Controls.Add(this.pokerBack);
            this.backGroup.Controls.Add(this.defBack);
            this.backGroup.ForeColor = System.Drawing.SystemColors.ControlText;
            this.backGroup.Location = new System.Drawing.Point(4, 484);
            this.backGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.backGroup.Name = "backGroup";
            this.backGroup.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.backGroup.Size = new System.Drawing.Size(162, 197);
            this.backGroup.TabIndex = 9;
            this.backGroup.TabStop = false;
            this.backGroup.Text = "Card Backs";
            // 
            // fancyGuildsBack
            // 
            this.fancyGuildsBack.AutoSize = true;
            this.fancyGuildsBack.Enabled = false;
            this.fancyGuildsBack.Location = new System.Drawing.Point(17, 128);
            this.fancyGuildsBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fancyGuildsBack.Name = "fancyGuildsBack";
            this.fancyGuildsBack.Size = new System.Drawing.Size(138, 24);
            this.fancyGuildsBack.TabIndex = 3;
            this.fancyGuildsBack.TabStop = true;
            this.fancyGuildsBack.Tag = "50";
            this.fancyGuildsBack.Text = "Requires Level 5";
            this.fancyGuildsBack.UseVisualStyleBackColor = true;
            this.fancyGuildsBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // guildsBack
            // 
            this.guildsBack.AutoSize = true;
            this.guildsBack.Enabled = false;
            this.guildsBack.Location = new System.Drawing.Point(17, 96);
            this.guildsBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guildsBack.Name = "guildsBack";
            this.guildsBack.Size = new System.Drawing.Size(138, 24);
            this.guildsBack.TabIndex = 2;
            this.guildsBack.TabStop = true;
            this.guildsBack.Tag = "30";
            this.guildsBack.Text = "Requires Level 3";
            this.guildsBack.UseVisualStyleBackColor = true;
            this.guildsBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // arcanaBack
            // 
            this.arcanaBack.AutoSize = true;
            this.arcanaBack.Enabled = false;
            this.arcanaBack.Location = new System.Drawing.Point(17, 160);
            this.arcanaBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.arcanaBack.Name = "arcanaBack";
            this.arcanaBack.Size = new System.Drawing.Size(138, 24);
            this.arcanaBack.TabIndex = 4;
            this.arcanaBack.TabStop = true;
            this.arcanaBack.Tag = "70";
            this.arcanaBack.Text = "Requires Level 7";
            this.arcanaBack.UseVisualStyleBackColor = true;
            this.arcanaBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // pokerBack
            // 
            this.pokerBack.AutoSize = true;
            this.pokerBack.Enabled = false;
            this.pokerBack.Location = new System.Drawing.Point(17, 64);
            this.pokerBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pokerBack.Name = "pokerBack";
            this.pokerBack.Size = new System.Drawing.Size(138, 24);
            this.pokerBack.TabIndex = 1;
            this.pokerBack.TabStop = true;
            this.pokerBack.Tag = "10";
            this.pokerBack.Text = "Requires Level 1";
            this.pokerBack.UseVisualStyleBackColor = true;
            this.pokerBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // defBack
            // 
            this.defBack.AutoSize = true;
            this.defBack.Enabled = false;
            this.defBack.Location = new System.Drawing.Point(17, 32);
            this.defBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.defBack.Name = "defBack";
            this.defBack.Size = new System.Drawing.Size(80, 24);
            this.defBack.TabIndex = 0;
            this.defBack.TabStop = true;
            this.defBack.Tag = "0";
            this.defBack.Text = "Default";
            this.defBack.UseVisualStyleBackColor = true;
            this.defBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // frontGroup
            // 
            this.frontGroup.Controls.Add(this.fancyGuildsFront);
            this.frontGroup.Controls.Add(this.guildsFront);
            this.frontGroup.Controls.Add(this.arcanaFront);
            this.frontGroup.Controls.Add(this.pokerFront);
            this.frontGroup.Controls.Add(this.defaultFront);
            this.frontGroup.ForeColor = System.Drawing.SystemColors.ControlText;
            this.frontGroup.Location = new System.Drawing.Point(4, 278);
            this.frontGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.frontGroup.Name = "frontGroup";
            this.frontGroup.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.frontGroup.Size = new System.Drawing.Size(162, 207);
            this.frontGroup.TabIndex = 8;
            this.frontGroup.TabStop = false;
            this.frontGroup.Text = "Card Fronts";
            // 
            // fancyGuildsFront
            // 
            this.fancyGuildsFront.AutoSize = true;
            this.fancyGuildsFront.Enabled = false;
            this.fancyGuildsFront.Location = new System.Drawing.Point(17, 127);
            this.fancyGuildsFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fancyGuildsFront.Name = "fancyGuildsFront";
            this.fancyGuildsFront.Size = new System.Drawing.Size(138, 24);
            this.fancyGuildsFront.TabIndex = 3;
            this.fancyGuildsFront.TabStop = true;
            this.fancyGuildsFront.Tag = "60";
            this.fancyGuildsFront.Text = "Requires Level 6";
            this.fancyGuildsFront.UseVisualStyleBackColor = true;
            this.fancyGuildsFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // guildsFront
            // 
            this.guildsFront.AutoSize = true;
            this.guildsFront.Enabled = false;
            this.guildsFront.Location = new System.Drawing.Point(17, 95);
            this.guildsFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.guildsFront.Name = "guildsFront";
            this.guildsFront.Size = new System.Drawing.Size(138, 24);
            this.guildsFront.TabIndex = 2;
            this.guildsFront.TabStop = true;
            this.guildsFront.Tag = "40";
            this.guildsFront.Text = "Requires Level 4";
            this.guildsFront.UseVisualStyleBackColor = true;
            this.guildsFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // arcanaFront
            // 
            this.arcanaFront.AutoSize = true;
            this.arcanaFront.Enabled = false;
            this.arcanaFront.Location = new System.Drawing.Point(17, 159);
            this.arcanaFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.arcanaFront.Name = "arcanaFront";
            this.arcanaFront.Size = new System.Drawing.Size(138, 24);
            this.arcanaFront.TabIndex = 4;
            this.arcanaFront.TabStop = true;
            this.arcanaFront.Tag = "80";
            this.arcanaFront.Text = "Requires Level 8";
            this.arcanaFront.UseVisualStyleBackColor = true;
            this.arcanaFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // pokerFront
            // 
            this.pokerFront.AutoSize = true;
            this.pokerFront.Enabled = false;
            this.pokerFront.Location = new System.Drawing.Point(17, 63);
            this.pokerFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pokerFront.Name = "pokerFront";
            this.pokerFront.Size = new System.Drawing.Size(138, 24);
            this.pokerFront.TabIndex = 1;
            this.pokerFront.TabStop = true;
            this.pokerFront.Tag = "20";
            this.pokerFront.Text = "Requires Level 2";
            this.pokerFront.UseVisualStyleBackColor = true;
            this.pokerFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // defaultFront
            // 
            this.defaultFront.AutoSize = true;
            this.defaultFront.Enabled = false;
            this.defaultFront.Location = new System.Drawing.Point(17, 31);
            this.defaultFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.defaultFront.Name = "defaultFront";
            this.defaultFront.Size = new System.Drawing.Size(80, 24);
            this.defaultFront.TabIndex = 0;
            this.defaultFront.TabStop = true;
            this.defaultFront.Tag = "0";
            this.defaultFront.Text = "Default";
            this.defaultFront.UseVisualStyleBackColor = true;
            this.defaultFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // optionsNewProfileTextBox
            // 
            this.optionsNewProfileTextBox.BackColor = System.Drawing.SystemColors.ControlDark;
            this.optionsNewProfileTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.optionsNewProfileTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.optionsNewProfileTextBox.Location = new System.Drawing.Point(60, 59);
            this.optionsNewProfileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.optionsNewProfileTextBox.Name = "optionsNewProfileTextBox";
            this.optionsNewProfileTextBox.Size = new System.Drawing.Size(171, 25);
            this.optionsNewProfileTextBox.TabIndex = 7;
            this.optionsNewProfileTextBox.Text = "CreateProfile";
            // 
            // optionsNewProfileButton
            // 
            this.optionsNewProfileButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.optionsNewProfileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.optionsNewProfileButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.optionsNewProfileButton.Location = new System.Drawing.Point(60, 88);
            this.optionsNewProfileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.optionsNewProfileButton.Name = "optionsNewProfileButton";
            this.optionsNewProfileButton.Size = new System.Drawing.Size(171, 46);
            this.optionsNewProfileButton.TabIndex = 7;
            this.optionsNewProfileButton.Text = "New Profile";
            this.optionsNewProfileButton.UseVisualStyleBackColor = false;
            this.optionsNewProfileButton.Click += new System.EventHandler(this.optionsNewProfileButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(33, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Profile";
            // 
            // profileBox
            // 
            this.profileBox.BackColor = System.Drawing.SystemColors.ControlDark;
            this.profileBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.profileBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.profileBox.FormattingEnabled = true;
            this.profileBox.Location = new System.Drawing.Point(92, 141);
            this.profileBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.profileBox.Name = "profileBox";
            this.profileBox.Size = new System.Drawing.Size(171, 27);
            this.profileBox.TabIndex = 1;
            this.profileBox.SelectedIndexChanged += new System.EventHandler(this.profileBox_SelectedIndexChanged);
            // 
            // optionsExitButton
            // 
            this.optionsExitButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.optionsExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.optionsExitButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.optionsExitButton.Location = new System.Drawing.Point(81, 684);
            this.optionsExitButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.optionsExitButton.Name = "optionsExitButton";
            this.optionsExitButton.Size = new System.Drawing.Size(75, 27);
            this.optionsExitButton.TabIndex = 0;
            this.optionsExitButton.Text = "Exit";
            this.optionsExitButton.UseVisualStyleBackColor = false;
            this.optionsExitButton.Click += new System.EventHandler(this.optionsExitButton_Click);
            // 
            // pregamePanel
            // 
            this.pregamePanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pregamePanel.Controls.Add(this.backButton);
            this.pregamePanel.Controls.Add(this.tableLayoutPanel2);
            this.pregamePanel.Controls.Add(this.pregameMultiOptions);
            this.pregamePanel.Controls.Add(this.pregameSingleOptions);
            this.pregamePanel.Controls.Add(this.sharedPanel);
            this.pregamePanel.Location = new System.Drawing.Point(12, 6);
            this.pregamePanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pregamePanel.Name = "pregamePanel";
            this.pregamePanel.Size = new System.Drawing.Size(430, 717);
            this.pregamePanel.TabIndex = 2;
            this.pregamePanel.Visible = false;
            // 
            // backButton
            // 
            this.backButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.backButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.backButton.Location = new System.Drawing.Point(315, 134);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(110, 50);
            this.backButton.TabIndex = 8;
            this.backButton.Text = "Main Menu";
            this.backButton.UseVisualStyleBackColor = false;
            this.backButton.Click += new System.EventHandler(this.menuButton_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.multiplayerButton, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.singleplayerButton, 0, 0);
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 4);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(424, 119);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // multiplayerButton
            // 
            this.multiplayerButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.multiplayerButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiplayerButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.multiplayerButton.Location = new System.Drawing.Point(215, 4);
            this.multiplayerButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiplayerButton.Name = "multiplayerButton";
            this.multiplayerButton.Size = new System.Drawing.Size(206, 111);
            this.multiplayerButton.TabIndex = 1;
            this.multiplayerButton.Text = "Multiplayer";
            this.multiplayerButton.UseVisualStyleBackColor = false;
            this.multiplayerButton.Click += new System.EventHandler(this.multiplayerButton_Click);
            // 
            // singleplayerButton
            // 
            this.singleplayerButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.singleplayerButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.singleplayerButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleplayerButton.Location = new System.Drawing.Point(3, 4);
            this.singleplayerButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleplayerButton.Name = "singleplayerButton";
            this.singleplayerButton.Size = new System.Drawing.Size(206, 111);
            this.singleplayerButton.TabIndex = 0;
            this.singleplayerButton.Text = "Single Player";
            this.singleplayerButton.UseVisualStyleBackColor = false;
            this.singleplayerButton.Click += new System.EventHandler(this.singleplayerButton_Click);
            // 
            // pregameMultiOptions
            // 
            this.pregameMultiOptions.Controls.Add(this.multiplayerProfilesError);
            this.pregameMultiOptions.Controls.Add(this.groupBox2);
            this.pregameMultiOptions.Controls.Add(this.groupBox1);
            this.pregameMultiOptions.Controls.Add(this.player2Name);
            this.pregameMultiOptions.Controls.Add(this.player1Name);
            this.pregameMultiOptions.Controls.Add(this.label8);
            this.pregameMultiOptions.Controls.Add(this.multiProfileList2);
            this.pregameMultiOptions.Controls.Add(this.label7);
            this.pregameMultiOptions.Controls.Add(this.multiNewProfileTextBox);
            this.pregameMultiOptions.Controls.Add(this.multiNewProfileButton);
            this.pregameMultiOptions.Controls.Add(this.multiProfileList1);
            this.pregameMultiOptions.Controls.Add(this.multiplayerStart);
            this.pregameMultiOptions.Location = new System.Drawing.Point(5, 189);
            this.pregameMultiOptions.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pregameMultiOptions.Name = "pregameMultiOptions";
            this.pregameMultiOptions.Size = new System.Drawing.Size(425, 485);
            this.pregameMultiOptions.TabIndex = 7;
            this.pregameMultiOptions.Visible = false;
            // 
            // multiplayerProfilesError
            // 
            this.multiplayerProfilesError.AutoSize = true;
            this.multiplayerProfilesError.ForeColor = System.Drawing.Color.Red;
            this.multiplayerProfilesError.Location = new System.Drawing.Point(244, 10);
            this.multiplayerProfilesError.Name = "multiplayerProfilesError";
            this.multiplayerProfilesError.Size = new System.Drawing.Size(172, 20);
            this.multiplayerProfilesError.TabIndex = 13;
            this.multiplayerProfilesError.Text = "Choose different players";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.multiBackGuilds);
            this.groupBox2.Controls.Add(this.multiBackFancyGuilds);
            this.groupBox2.Controls.Add(this.multiBackArcana);
            this.groupBox2.Controls.Add(this.multiBackPoker);
            this.groupBox2.Controls.Add(this.multiBackDefault);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox2.Location = new System.Drawing.Point(156, 269);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(124, 197);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Card Backs";
            // 
            // multiBackGuilds
            // 
            this.multiBackGuilds.AutoSize = true;
            this.multiBackGuilds.Location = new System.Drawing.Point(6, 90);
            this.multiBackGuilds.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiBackGuilds.Name = "multiBackGuilds";
            this.multiBackGuilds.Size = new System.Drawing.Size(72, 24);
            this.multiBackGuilds.TabIndex = 2;
            this.multiBackGuilds.TabStop = true;
            this.multiBackGuilds.Tag = "30";
            this.multiBackGuilds.Text = "Guilds";
            this.multiBackGuilds.UseVisualStyleBackColor = true;
            this.multiBackGuilds.CheckedChanged += new System.EventHandler(this.changeBackMulti);
            // 
            // multiBackFancyGuilds
            // 
            this.multiBackFancyGuilds.AutoSize = true;
            this.multiBackFancyGuilds.Location = new System.Drawing.Point(6, 122);
            this.multiBackFancyGuilds.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiBackFancyGuilds.Name = "multiBackFancyGuilds";
            this.multiBackFancyGuilds.Size = new System.Drawing.Size(119, 24);
            this.multiBackFancyGuilds.TabIndex = 3;
            this.multiBackFancyGuilds.TabStop = true;
            this.multiBackFancyGuilds.Tag = "50";
            this.multiBackFancyGuilds.Text = "Stylish Guilds";
            this.multiBackFancyGuilds.UseVisualStyleBackColor = true;
            this.multiBackFancyGuilds.CheckedChanged += new System.EventHandler(this.changeBackMulti);
            // 
            // multiBackArcana
            // 
            this.multiBackArcana.AutoSize = true;
            this.multiBackArcana.Location = new System.Drawing.Point(6, 154);
            this.multiBackArcana.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiBackArcana.Name = "multiBackArcana";
            this.multiBackArcana.Size = new System.Drawing.Size(77, 24);
            this.multiBackArcana.TabIndex = 4;
            this.multiBackArcana.TabStop = true;
            this.multiBackArcana.Tag = "30";
            this.multiBackArcana.Text = "Arcana";
            this.multiBackArcana.UseVisualStyleBackColor = true;
            this.multiBackArcana.CheckedChanged += new System.EventHandler(this.changeBackMulti);
            // 
            // multiBackPoker
            // 
            this.multiBackPoker.AutoSize = true;
            this.multiBackPoker.Location = new System.Drawing.Point(6, 58);
            this.multiBackPoker.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiBackPoker.Name = "multiBackPoker";
            this.multiBackPoker.Size = new System.Drawing.Size(69, 24);
            this.multiBackPoker.TabIndex = 1;
            this.multiBackPoker.TabStop = true;
            this.multiBackPoker.Tag = "10";
            this.multiBackPoker.Text = "Poker";
            this.multiBackPoker.UseVisualStyleBackColor = true;
            this.multiBackPoker.CheckedChanged += new System.EventHandler(this.changeBackMulti);
            // 
            // multiBackDefault
            // 
            this.multiBackDefault.AutoSize = true;
            this.multiBackDefault.Location = new System.Drawing.Point(6, 26);
            this.multiBackDefault.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiBackDefault.Name = "multiBackDefault";
            this.multiBackDefault.Size = new System.Drawing.Size(80, 24);
            this.multiBackDefault.TabIndex = 0;
            this.multiBackDefault.TabStop = true;
            this.multiBackDefault.Tag = "0";
            this.multiBackDefault.Text = "Default";
            this.multiBackDefault.UseVisualStyleBackColor = true;
            this.multiBackDefault.CheckedChanged += new System.EventHandler(this.changeBackMulti);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.multiFrontGuilds);
            this.groupBox1.Controls.Add(this.multiFrontFancyGuilds);
            this.groupBox1.Controls.Add(this.multiFrontArcana);
            this.groupBox1.Controls.Add(this.multiFrontPoker);
            this.groupBox1.Controls.Add(this.multiFrontDefault);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBox1.Location = new System.Drawing.Point(15, 269);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(124, 197);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Card Fronts";
            // 
            // multiFrontGuilds
            // 
            this.multiFrontGuilds.AutoSize = true;
            this.multiFrontGuilds.Location = new System.Drawing.Point(6, 90);
            this.multiFrontGuilds.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiFrontGuilds.Name = "multiFrontGuilds";
            this.multiFrontGuilds.Size = new System.Drawing.Size(72, 24);
            this.multiFrontGuilds.TabIndex = 2;
            this.multiFrontGuilds.TabStop = true;
            this.multiFrontGuilds.Tag = "40";
            this.multiFrontGuilds.Text = "Guilds";
            this.multiFrontGuilds.UseVisualStyleBackColor = true;
            this.multiFrontGuilds.CheckedChanged += new System.EventHandler(this.changeFrontMulti);
            // 
            // multiFrontFancyGuilds
            // 
            this.multiFrontFancyGuilds.AutoSize = true;
            this.multiFrontFancyGuilds.Location = new System.Drawing.Point(6, 122);
            this.multiFrontFancyGuilds.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiFrontFancyGuilds.Name = "multiFrontFancyGuilds";
            this.multiFrontFancyGuilds.Size = new System.Drawing.Size(119, 24);
            this.multiFrontFancyGuilds.TabIndex = 3;
            this.multiFrontFancyGuilds.TabStop = true;
            this.multiFrontFancyGuilds.Tag = "60";
            this.multiFrontFancyGuilds.Text = "Stylish Guilds";
            this.multiFrontFancyGuilds.UseVisualStyleBackColor = true;
            this.multiFrontFancyGuilds.CheckedChanged += new System.EventHandler(this.changeFrontMulti);
            // 
            // multiFrontArcana
            // 
            this.multiFrontArcana.AutoSize = true;
            this.multiFrontArcana.Location = new System.Drawing.Point(6, 154);
            this.multiFrontArcana.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiFrontArcana.Name = "multiFrontArcana";
            this.multiFrontArcana.Size = new System.Drawing.Size(77, 24);
            this.multiFrontArcana.TabIndex = 4;
            this.multiFrontArcana.TabStop = true;
            this.multiFrontArcana.Tag = "40";
            this.multiFrontArcana.Text = "Arcana";
            this.multiFrontArcana.UseVisualStyleBackColor = true;
            this.multiFrontArcana.CheckedChanged += new System.EventHandler(this.changeFrontMulti);
            // 
            // multiFrontPoker
            // 
            this.multiFrontPoker.AutoSize = true;
            this.multiFrontPoker.Location = new System.Drawing.Point(6, 58);
            this.multiFrontPoker.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiFrontPoker.Name = "multiFrontPoker";
            this.multiFrontPoker.Size = new System.Drawing.Size(69, 24);
            this.multiFrontPoker.TabIndex = 1;
            this.multiFrontPoker.TabStop = true;
            this.multiFrontPoker.Tag = "20";
            this.multiFrontPoker.Text = "Poker";
            this.multiFrontPoker.UseVisualStyleBackColor = true;
            this.multiFrontPoker.CheckedChanged += new System.EventHandler(this.changeFrontMulti);
            // 
            // multiFrontDefault
            // 
            this.multiFrontDefault.AutoSize = true;
            this.multiFrontDefault.Location = new System.Drawing.Point(6, 26);
            this.multiFrontDefault.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiFrontDefault.Name = "multiFrontDefault";
            this.multiFrontDefault.Size = new System.Drawing.Size(80, 24);
            this.multiFrontDefault.TabIndex = 0;
            this.multiFrontDefault.TabStop = true;
            this.multiFrontDefault.Tag = "0";
            this.multiFrontDefault.Text = "Default";
            this.multiFrontDefault.UseVisualStyleBackColor = true;
            this.multiFrontDefault.CheckedChanged += new System.EventHandler(this.changeFrontMulti);
            // 
            // player2Name
            // 
            this.player2Name.AutoSize = true;
            this.player2Name.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player2Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.player2Name.Location = new System.Drawing.Point(153, 40);
            this.player2Name.Name = "player2Name";
            this.player2Name.Size = new System.Drawing.Size(0, 24);
            this.player2Name.TabIndex = 11;
            // 
            // player1Name
            // 
            this.player1Name.AutoSize = true;
            this.player1Name.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.player1Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.player1Name.Location = new System.Drawing.Point(11, 40);
            this.player1Name.Name = "player1Name";
            this.player1Name.Size = new System.Drawing.Size(0, 24);
            this.player1Name.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(153, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = "Player 2:";
            // 
            // multiProfileList2
            // 
            this.multiProfileList2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.multiProfileList2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.multiProfileList2.CausesValidation = false;
            this.multiProfileList2.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiProfileList2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.multiProfileList2.FormattingEnabled = true;
            this.multiProfileList2.ItemHeight = 27;
            this.multiProfileList2.Location = new System.Drawing.Point(156, 68);
            this.multiProfileList2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiProfileList2.Name = "multiProfileList2";
            this.multiProfileList2.Size = new System.Drawing.Size(124, 191);
            this.multiProfileList2.TabIndex = 8;
            this.multiProfileList2.Click += new System.EventHandler(this.multiProfileList2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(11, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "Player 1:";
            // 
            // multiNewProfileTextBox
            // 
            this.multiNewProfileTextBox.BackColor = System.Drawing.SystemColors.ControlDark;
            this.multiNewProfileTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.multiNewProfileTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.multiNewProfileTextBox.Location = new System.Drawing.Point(292, 68);
            this.multiNewProfileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiNewProfileTextBox.Name = "multiNewProfileTextBox";
            this.multiNewProfileTextBox.Size = new System.Drawing.Size(129, 25);
            this.multiNewProfileTextBox.TabIndex = 6;
            this.multiNewProfileTextBox.Text = "CreateProfile";
            // 
            // multiNewProfileButton
            // 
            this.multiNewProfileButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.multiNewProfileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiNewProfileButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.multiNewProfileButton.Location = new System.Drawing.Point(291, 98);
            this.multiNewProfileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiNewProfileButton.Name = "multiNewProfileButton";
            this.multiNewProfileButton.Size = new System.Drawing.Size(130, 46);
            this.multiNewProfileButton.TabIndex = 3;
            this.multiNewProfileButton.Text = "New Profile";
            this.multiNewProfileButton.UseVisualStyleBackColor = false;
            this.multiNewProfileButton.Click += new System.EventHandler(this.multiNewProfileButton_Click);
            // 
            // multiProfileList1
            // 
            this.multiProfileList1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.multiProfileList1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.multiProfileList1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiProfileList1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.multiProfileList1.FormattingEnabled = true;
            this.multiProfileList1.ItemHeight = 27;
            this.multiProfileList1.Location = new System.Drawing.Point(14, 68);
            this.multiProfileList1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiProfileList1.Name = "multiProfileList1";
            this.multiProfileList1.Size = new System.Drawing.Size(124, 191);
            this.multiProfileList1.TabIndex = 2;
            this.multiProfileList1.Click += new System.EventHandler(this.multiProfileList1_Click);
            // 
            // multiplayerStart
            // 
            this.multiplayerStart.BackColor = System.Drawing.SystemColors.ControlDark;
            this.multiplayerStart.Enabled = false;
            this.multiplayerStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.multiplayerStart.ForeColor = System.Drawing.SystemColors.ControlText;
            this.multiplayerStart.Location = new System.Drawing.Point(286, 402);
            this.multiplayerStart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.multiplayerStart.Name = "multiplayerStart";
            this.multiplayerStart.Size = new System.Drawing.Size(130, 64);
            this.multiplayerStart.TabIndex = 1;
            this.multiplayerStart.Text = "Start Game";
            this.multiplayerStart.UseVisualStyleBackColor = false;
            this.multiplayerStart.Click += new System.EventHandler(this.multiplayerStart_Click);
            // 
            // pregameSingleOptions
            // 
            this.pregameSingleOptions.Controls.Add(this.singleplayerProfileError);
            this.pregameSingleOptions.Controls.Add(this.singleBackGroup);
            this.pregameSingleOptions.Controls.Add(this.singleFrontGroup);
            this.pregameSingleOptions.Controls.Add(this.label5);
            this.pregameSingleOptions.Controls.Add(this.xpBar);
            this.pregameSingleOptions.Controls.Add(this.singleXp);
            this.pregameSingleOptions.Controls.Add(this.singleStreak);
            this.pregameSingleOptions.Controls.Add(this.singleLosses);
            this.pregameSingleOptions.Controls.Add(this.singleWins);
            this.pregameSingleOptions.Controls.Add(this.singleProfileList);
            this.pregameSingleOptions.Controls.Add(this.singleNewProfileTextBox);
            this.pregameSingleOptions.Controls.Add(this.profileNameLabel);
            this.pregameSingleOptions.Controls.Add(this.label3);
            this.pregameSingleOptions.Controls.Add(this.singleNewProfileButton);
            this.pregameSingleOptions.Controls.Add(this.singleplayerStart);
            this.pregameSingleOptions.Controls.Add(this.difficultyGroup);
            this.pregameSingleOptions.Location = new System.Drawing.Point(0, 189);
            this.pregameSingleOptions.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pregameSingleOptions.Name = "pregameSingleOptions";
            this.pregameSingleOptions.Size = new System.Drawing.Size(425, 492);
            this.pregameSingleOptions.TabIndex = 3;
            this.pregameSingleOptions.Visible = false;
            // 
            // singleplayerProfileError
            // 
            this.singleplayerProfileError.AutoSize = true;
            this.singleplayerProfileError.ForeColor = System.Drawing.Color.Red;
            this.singleplayerProfileError.Location = new System.Drawing.Point(292, 119);
            this.singleplayerProfileError.Name = "singleplayerProfileError";
            this.singleplayerProfileError.Size = new System.Drawing.Size(119, 20);
            this.singleplayerProfileError.TabIndex = 14;
            this.singleplayerProfileError.Text = "Choose a profile";
            // 
            // singleBackGroup
            // 
            this.singleBackGroup.Controls.Add(this.singleFancyGuildsBack);
            this.singleBackGroup.Controls.Add(this.singleGuildsBack);
            this.singleBackGroup.Controls.Add(this.singleArcanaBack);
            this.singleBackGroup.Controls.Add(this.singlePokerBack);
            this.singleBackGroup.Controls.Add(this.singledefaultBack);
            this.singleBackGroup.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleBackGroup.Location = new System.Drawing.Point(190, 286);
            this.singleBackGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleBackGroup.Name = "singleBackGroup";
            this.singleBackGroup.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleBackGroup.Size = new System.Drawing.Size(174, 195);
            this.singleBackGroup.TabIndex = 10;
            this.singleBackGroup.TabStop = false;
            this.singleBackGroup.Text = "Card Backs";
            // 
            // singleFancyGuildsBack
            // 
            this.singleFancyGuildsBack.AutoSize = true;
            this.singleFancyGuildsBack.Enabled = false;
            this.singleFancyGuildsBack.Location = new System.Drawing.Point(16, 122);
            this.singleFancyGuildsBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleFancyGuildsBack.Name = "singleFancyGuildsBack";
            this.singleFancyGuildsBack.Size = new System.Drawing.Size(138, 24);
            this.singleFancyGuildsBack.TabIndex = 3;
            this.singleFancyGuildsBack.TabStop = true;
            this.singleFancyGuildsBack.Tag = "50";
            this.singleFancyGuildsBack.Text = "Requires Level 5";
            this.singleFancyGuildsBack.UseVisualStyleBackColor = true;
            this.singleFancyGuildsBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // singleGuildsBack
            // 
            this.singleGuildsBack.AutoSize = true;
            this.singleGuildsBack.Enabled = false;
            this.singleGuildsBack.Location = new System.Drawing.Point(16, 90);
            this.singleGuildsBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleGuildsBack.Name = "singleGuildsBack";
            this.singleGuildsBack.Size = new System.Drawing.Size(138, 24);
            this.singleGuildsBack.TabIndex = 2;
            this.singleGuildsBack.TabStop = true;
            this.singleGuildsBack.Tag = "30";
            this.singleGuildsBack.Text = "Requires Level 3";
            this.singleGuildsBack.UseVisualStyleBackColor = true;
            this.singleGuildsBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // singleArcanaBack
            // 
            this.singleArcanaBack.AutoSize = true;
            this.singleArcanaBack.Enabled = false;
            this.singleArcanaBack.Location = new System.Drawing.Point(16, 154);
            this.singleArcanaBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleArcanaBack.Name = "singleArcanaBack";
            this.singleArcanaBack.Size = new System.Drawing.Size(138, 24);
            this.singleArcanaBack.TabIndex = 4;
            this.singleArcanaBack.TabStop = true;
            this.singleArcanaBack.Tag = "70";
            this.singleArcanaBack.Text = "Requires Level 7";
            this.singleArcanaBack.UseVisualStyleBackColor = true;
            this.singleArcanaBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // singlePokerBack
            // 
            this.singlePokerBack.AutoSize = true;
            this.singlePokerBack.Enabled = false;
            this.singlePokerBack.Location = new System.Drawing.Point(16, 58);
            this.singlePokerBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singlePokerBack.Name = "singlePokerBack";
            this.singlePokerBack.Size = new System.Drawing.Size(138, 24);
            this.singlePokerBack.TabIndex = 1;
            this.singlePokerBack.TabStop = true;
            this.singlePokerBack.Tag = "10";
            this.singlePokerBack.Text = "Requires Level 1";
            this.singlePokerBack.UseVisualStyleBackColor = true;
            this.singlePokerBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // singledefaultBack
            // 
            this.singledefaultBack.AutoSize = true;
            this.singledefaultBack.Enabled = false;
            this.singledefaultBack.Location = new System.Drawing.Point(16, 26);
            this.singledefaultBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singledefaultBack.Name = "singledefaultBack";
            this.singledefaultBack.Size = new System.Drawing.Size(80, 24);
            this.singledefaultBack.TabIndex = 0;
            this.singledefaultBack.TabStop = true;
            this.singledefaultBack.Tag = "0";
            this.singledefaultBack.Text = "Default";
            this.singledefaultBack.UseVisualStyleBackColor = true;
            this.singledefaultBack.CheckedChanged += new System.EventHandler(this.changeBack);
            // 
            // singleFrontGroup
            // 
            this.singleFrontGroup.Controls.Add(this.singleFancyGuildsFront);
            this.singleFrontGroup.Controls.Add(this.singleGuildsFront);
            this.singleFrontGroup.Controls.Add(this.singleArcanaFront);
            this.singleFrontGroup.Controls.Add(this.singlePokerFront);
            this.singleFrontGroup.Controls.Add(this.singleDefaultFront);
            this.singleFrontGroup.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleFrontGroup.Location = new System.Drawing.Point(11, 286);
            this.singleFrontGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleFrontGroup.Name = "singleFrontGroup";
            this.singleFrontGroup.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleFrontGroup.Size = new System.Drawing.Size(173, 193);
            this.singleFrontGroup.TabIndex = 9;
            this.singleFrontGroup.TabStop = false;
            this.singleFrontGroup.Text = "Card Fronts";
            // 
            // singleFancyGuildsFront
            // 
            this.singleFancyGuildsFront.AutoSize = true;
            this.singleFancyGuildsFront.Enabled = false;
            this.singleFancyGuildsFront.Location = new System.Drawing.Point(14, 122);
            this.singleFancyGuildsFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleFancyGuildsFront.Name = "singleFancyGuildsFront";
            this.singleFancyGuildsFront.Size = new System.Drawing.Size(138, 24);
            this.singleFancyGuildsFront.TabIndex = 3;
            this.singleFancyGuildsFront.TabStop = true;
            this.singleFancyGuildsFront.Tag = "60";
            this.singleFancyGuildsFront.Text = "Requires Level 6";
            this.singleFancyGuildsFront.UseVisualStyleBackColor = true;
            this.singleFancyGuildsFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // singleGuildsFront
            // 
            this.singleGuildsFront.AutoSize = true;
            this.singleGuildsFront.Enabled = false;
            this.singleGuildsFront.Location = new System.Drawing.Point(14, 90);
            this.singleGuildsFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleGuildsFront.Name = "singleGuildsFront";
            this.singleGuildsFront.Size = new System.Drawing.Size(138, 24);
            this.singleGuildsFront.TabIndex = 2;
            this.singleGuildsFront.TabStop = true;
            this.singleGuildsFront.Tag = "40";
            this.singleGuildsFront.Text = "Requires Level 4";
            this.singleGuildsFront.UseVisualStyleBackColor = true;
            this.singleGuildsFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // singleArcanaFront
            // 
            this.singleArcanaFront.AutoSize = true;
            this.singleArcanaFront.Enabled = false;
            this.singleArcanaFront.Location = new System.Drawing.Point(14, 154);
            this.singleArcanaFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleArcanaFront.Name = "singleArcanaFront";
            this.singleArcanaFront.Size = new System.Drawing.Size(138, 24);
            this.singleArcanaFront.TabIndex = 4;
            this.singleArcanaFront.TabStop = true;
            this.singleArcanaFront.Tag = "80";
            this.singleArcanaFront.Text = "Requires Level 8";
            this.singleArcanaFront.UseVisualStyleBackColor = true;
            this.singleArcanaFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // singlePokerFront
            // 
            this.singlePokerFront.AutoSize = true;
            this.singlePokerFront.Enabled = false;
            this.singlePokerFront.Location = new System.Drawing.Point(14, 58);
            this.singlePokerFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singlePokerFront.Name = "singlePokerFront";
            this.singlePokerFront.Size = new System.Drawing.Size(138, 24);
            this.singlePokerFront.TabIndex = 1;
            this.singlePokerFront.TabStop = true;
            this.singlePokerFront.Tag = "20";
            this.singlePokerFront.Text = "Requires Level 2";
            this.singlePokerFront.UseVisualStyleBackColor = true;
            this.singlePokerFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // singleDefaultFront
            // 
            this.singleDefaultFront.AutoSize = true;
            this.singleDefaultFront.Enabled = false;
            this.singleDefaultFront.Location = new System.Drawing.Point(14, 26);
            this.singleDefaultFront.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleDefaultFront.Name = "singleDefaultFront";
            this.singleDefaultFront.Size = new System.Drawing.Size(80, 24);
            this.singleDefaultFront.TabIndex = 0;
            this.singleDefaultFront.TabStop = true;
            this.singleDefaultFront.Tag = "0";
            this.singleDefaultFront.Text = "Default";
            this.singleDefaultFront.UseVisualStyleBackColor = true;
            this.singleDefaultFront.CheckedChanged += new System.EventHandler(this.changeFront);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(112, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = "Xp:";
            // 
            // xpBar
            // 
            this.xpBar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.xpBar.ForeColor = System.Drawing.Color.Red;
            this.xpBar.Location = new System.Drawing.Point(147, 243);
            this.xpBar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.xpBar.Maximum = 10;
            this.xpBar.Name = "xpBar";
            this.xpBar.Size = new System.Drawing.Size(134, 17);
            this.xpBar.TabIndex = 12;
            // 
            // singleXp
            // 
            this.singleXp.AutoSize = true;
            this.singleXp.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleXp.Location = new System.Drawing.Point(113, 220);
            this.singleXp.Name = "singleXp";
            this.singleXp.Size = new System.Drawing.Size(50, 20);
            this.singleXp.TabIndex = 11;
            this.singleXp.Text = "Level: ";
            // 
            // singleStreak
            // 
            this.singleStreak.AutoSize = true;
            this.singleStreak.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleStreak.Location = new System.Drawing.Point(113, 200);
            this.singleStreak.Name = "singleStreak";
            this.singleStreak.Size = new System.Drawing.Size(58, 20);
            this.singleStreak.TabIndex = 10;
            this.singleStreak.Text = "Streak: ";
            // 
            // singleLosses
            // 
            this.singleLosses.AutoSize = true;
            this.singleLosses.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleLosses.Location = new System.Drawing.Point(113, 179);
            this.singleLosses.Name = "singleLosses";
            this.singleLosses.Size = new System.Drawing.Size(58, 20);
            this.singleLosses.TabIndex = 9;
            this.singleLosses.Text = "Losses: ";
            // 
            // singleWins
            // 
            this.singleWins.AutoSize = true;
            this.singleWins.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleWins.Location = new System.Drawing.Point(113, 159);
            this.singleWins.Name = "singleWins";
            this.singleWins.Size = new System.Drawing.Size(49, 20);
            this.singleWins.TabIndex = 8;
            this.singleWins.Text = "Wins: ";
            // 
            // singleProfileList
            // 
            this.singleProfileList.BackColor = System.Drawing.SystemColors.ControlDark;
            this.singleProfileList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.singleProfileList.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleProfileList.FormattingEnabled = true;
            this.singleProfileList.Location = new System.Drawing.Point(116, 119);
            this.singleProfileList.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleProfileList.Name = "singleProfileList";
            this.singleProfileList.Size = new System.Drawing.Size(170, 27);
            this.singleProfileList.TabIndex = 7;
            this.singleProfileList.SelectedIndexChanged += new System.EventHandler(this.singleProfileList_SelectedIndexChanged);
            // 
            // singleNewProfileTextBox
            // 
            this.singleNewProfileTextBox.BackColor = System.Drawing.SystemColors.ControlDark;
            this.singleNewProfileTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.singleNewProfileTextBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleNewProfileTextBox.Location = new System.Drawing.Point(116, 34);
            this.singleNewProfileTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleNewProfileTextBox.Name = "singleNewProfileTextBox";
            this.singleNewProfileTextBox.Size = new System.Drawing.Size(170, 25);
            this.singleNewProfileTextBox.TabIndex = 6;
            this.singleNewProfileTextBox.Text = "CreateProfile";
            // 
            // profileNameLabel
            // 
            this.profileNameLabel.AutoSize = true;
            this.profileNameLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.profileNameLabel.Location = new System.Drawing.Point(292, 184);
            this.profileNameLabel.Name = "profileNameLabel";
            this.profileNameLabel.Size = new System.Drawing.Size(0, 20);
            this.profileNameLabel.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(292, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Current Profile:";
            // 
            // singleNewProfileButton
            // 
            this.singleNewProfileButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.singleNewProfileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.singleNewProfileButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleNewProfileButton.Location = new System.Drawing.Point(115, 65);
            this.singleNewProfileButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleNewProfileButton.Name = "singleNewProfileButton";
            this.singleNewProfileButton.Size = new System.Drawing.Size(172, 46);
            this.singleNewProfileButton.TabIndex = 3;
            this.singleNewProfileButton.Text = "New Profile";
            this.singleNewProfileButton.UseVisualStyleBackColor = false;
            this.singleNewProfileButton.Click += new System.EventHandler(this.singleNewProfileButton_Click);
            // 
            // singleplayerStart
            // 
            this.singleplayerStart.BackColor = System.Drawing.SystemColors.ControlDark;
            this.singleplayerStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.singleplayerStart.ForeColor = System.Drawing.SystemColors.ControlText;
            this.singleplayerStart.Location = new System.Drawing.Point(292, 211);
            this.singleplayerStart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.singleplayerStart.Name = "singleplayerStart";
            this.singleplayerStart.Size = new System.Drawing.Size(130, 64);
            this.singleplayerStart.TabIndex = 1;
            this.singleplayerStart.Text = "Start Game";
            this.singleplayerStart.UseVisualStyleBackColor = false;
            this.singleplayerStart.Click += new System.EventHandler(this.singleplayerStart_Click);
            // 
            // difficultyGroup
            // 
            this.difficultyGroup.Controls.Add(this.difficultyPanel);
            this.difficultyGroup.Location = new System.Drawing.Point(4, 4);
            this.difficultyGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.difficultyGroup.Name = "difficultyGroup";
            this.difficultyGroup.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.difficultyGroup.Size = new System.Drawing.Size(105, 271);
            this.difficultyGroup.TabIndex = 0;
            this.difficultyGroup.TabStop = false;
            this.difficultyGroup.Text = "AI";
            // 
            // difficultyPanel
            // 
            this.difficultyPanel.ColumnCount = 1;
            this.difficultyPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.difficultyPanel.Controls.Add(this.difficultyHard, 0, 5);
            this.difficultyPanel.Controls.Add(this.difficultyMedium2, 0, 3);
            this.difficultyPanel.Controls.Add(this.difficultyGoldfish, 0, 0);
            this.difficultyPanel.Controls.Add(this.difficultyMedium, 0, 2);
            this.difficultyPanel.Controls.Add(this.difficultyEasy, 0, 1);
            this.difficultyPanel.Controls.Add(this.difficultyMedium3, 0, 4);
            this.difficultyPanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.difficultyPanel.Location = new System.Drawing.Point(2, 12);
            this.difficultyPanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.difficultyPanel.Name = "difficultyPanel";
            this.difficultyPanel.RowCount = 6;
            this.difficultyPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.difficultyPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.difficultyPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.difficultyPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.difficultyPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.difficultyPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.difficultyPanel.Size = new System.Drawing.Size(101, 253);
            this.difficultyPanel.TabIndex = 0;
            // 
            // difficultyHard
            // 
            this.difficultyHard.Location = new System.Drawing.Point(3, 214);
            this.difficultyHard.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.difficultyHard.Name = "difficultyHard";
            this.difficultyHard.Size = new System.Drawing.Size(95, 35);
            this.difficultyHard.TabIndex = 2;
            this.difficultyHard.Text = "Cheatyface";
            this.difficultyHard.UseVisualStyleBackColor = true;
            this.difficultyHard.CheckedChanged += new System.EventHandler(this.difficulty_CheckedChanged);
            // 
            // difficultyMedium2
            // 
            this.difficultyMedium2.AllowDrop = true;
            this.difficultyMedium2.Checked = true;
            this.difficultyMedium2.Location = new System.Drawing.Point(3, 129);
            this.difficultyMedium2.Name = "difficultyMedium2";
            this.difficultyMedium2.Size = new System.Drawing.Size(95, 36);
            this.difficultyMedium2.TabIndex = 4;
            this.difficultyMedium2.TabStop = true;
            this.difficultyMedium2.Text = "Middling Machine";
            this.difficultyMedium2.UseVisualStyleBackColor = true;
            this.difficultyMedium2.CheckedChanged += new System.EventHandler(this.difficulty_CheckedChanged);
            // 
            // difficultyGoldfish
            // 
            this.difficultyGoldfish.AllowDrop = true;
            this.difficultyGoldfish.Location = new System.Drawing.Point(3, 3);
            this.difficultyGoldfish.Name = "difficultyGoldfish";
            this.difficultyGoldfish.Size = new System.Drawing.Size(95, 36);
            this.difficultyGoldfish.TabIndex = 3;
            this.difficultyGoldfish.Text = "Goldfish";
            this.difficultyGoldfish.UseVisualStyleBackColor = true;
            this.difficultyGoldfish.CheckedChanged += new System.EventHandler(this.difficulty_CheckedChanged);
            // 
            // difficultyMedium
            // 
            this.difficultyMedium.AllowDrop = true;
            this.difficultyMedium.Location = new System.Drawing.Point(3, 88);
            this.difficultyMedium.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.difficultyMedium.Name = "difficultyMedium";
            this.difficultyMedium.Size = new System.Drawing.Size(95, 34);
            this.difficultyMedium.TabIndex = 1;
            this.difficultyMedium.Text = "Rusty Robot";
            this.difficultyMedium.UseVisualStyleBackColor = true;
            this.difficultyMedium.CheckedChanged += new System.EventHandler(this.difficulty_CheckedChanged);
            // 
            // difficultyEasy
            // 
            this.difficultyEasy.Location = new System.Drawing.Point(3, 46);
            this.difficultyEasy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.difficultyEasy.Name = "difficultyEasy";
            this.difficultyEasy.Size = new System.Drawing.Size(95, 34);
            this.difficultyEasy.TabIndex = 0;
            this.difficultyEasy.Text = "Baby Bot";
            this.difficultyEasy.UseVisualStyleBackColor = true;
            this.difficultyEasy.CheckedChanged += new System.EventHandler(this.difficulty_CheckedChanged);
            // 
            // difficultyMedium3
            // 
            this.difficultyMedium3.Location = new System.Drawing.Point(3, 171);
            this.difficultyMedium3.Name = "difficultyMedium3";
            this.difficultyMedium3.Size = new System.Drawing.Size(95, 36);
            this.difficultyMedium3.TabIndex = 5;
            this.difficultyMedium3.Text = "Danger Droid";
            this.difficultyMedium3.UseVisualStyleBackColor = true;
            this.difficultyMedium3.CheckedChanged += new System.EventHandler(this.difficulty_CheckedChanged);
            // 
            // sharedPanel
            // 
            this.sharedPanel.Controls.Add(this.label2);
            this.sharedPanel.Controls.Add(this.matchingBox);
            this.sharedPanel.Controls.Add(this.pairAmountTextBox);
            this.sharedPanel.Controls.Add(this.pairErrorLabel);
            this.sharedPanel.Location = new System.Drawing.Point(19, 134);
            this.sharedPanel.Name = "sharedPanel";
            this.sharedPanel.Size = new System.Drawing.Size(289, 580);
            this.sharedPanel.TabIndex = 6;
            this.sharedPanel.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(54, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pair Amount (2-10)";
            // 
            // matchingBox
            // 
            this.matchingBox.AutoSize = true;
            this.matchingBox.Enabled = false;
            this.matchingBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.matchingBox.Location = new System.Drawing.Point(16, 553);
            this.matchingBox.Name = "matchingBox";
            this.matchingBox.Size = new System.Drawing.Size(177, 24);
            this.matchingBox.TabIndex = 13;
            this.matchingBox.Text = "Match front and back";
            this.matchingBox.UseVisualStyleBackColor = true;
            // 
            // pairAmountTextBox
            // 
            this.pairAmountTextBox.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pairAmountTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pairAmountTextBox.Location = new System.Drawing.Point(58, 25);
            this.pairAmountTextBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pairAmountTextBox.Name = "pairAmountTextBox";
            this.pairAmountTextBox.Size = new System.Drawing.Size(100, 25);
            this.pairAmountTextBox.TabIndex = 0;
            this.pairAmountTextBox.Text = "2";
            this.pairAmountTextBox.TextChanged += new System.EventHandler(this.pairAmountTextBox_TextChanged);
            // 
            // pairErrorLabel
            // 
            this.pairErrorLabel.AutoSize = true;
            this.pairErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.pairErrorLabel.Location = new System.Drawing.Point(164, 28);
            this.pairErrorLabel.Name = "pairErrorLabel";
            this.pairErrorLabel.Size = new System.Drawing.Size(123, 20);
            this.pairErrorLabel.TabIndex = 4;
            this.pairErrorLabel.Text = "Not within range";
            this.pairErrorLabel.Visible = false;
            // 
            // gamePanel
            // 
            this.gamePanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.gamePanel.Controls.Add(this.player1Label);
            this.gamePanel.Controls.Add(this.gameLayoutPanel);
            this.gamePanel.Controls.Add(this.replayButton);
            this.gamePanel.Controls.Add(this.menuButton);
            this.gamePanel.Controls.Add(this.returnButton);
            this.gamePanel.Controls.Add(this.turnLabel);
            this.gamePanel.Controls.Add(this.player2Score);
            this.gamePanel.Controls.Add(this.player1Score);
            this.gamePanel.Controls.Add(this.player2Label);
            this.gamePanel.Controls.Add(this.label4);
            this.gamePanel.Location = new System.Drawing.Point(1141, 14);
            this.gamePanel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gamePanel.Name = "gamePanel";
            this.gamePanel.Size = new System.Drawing.Size(534, 747);
            this.gamePanel.TabIndex = 3;
            this.gamePanel.Visible = false;
            // 
            // player1Label
            // 
            this.player1Label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.player1Label.Location = new System.Drawing.Point(43, 0);
            this.player1Label.Name = "player1Label";
            this.player1Label.Size = new System.Drawing.Size(184, 20);
            this.player1Label.TabIndex = 6;
            this.player1Label.Text = "Player 1";
            this.player1Label.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gameLayoutPanel
            // 
            this.gameLayoutPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gameLayoutPanel.ColumnCount = 5;
            this.gameLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.gameLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.gameLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.gameLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.gameLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.gameLayoutPanel.Controls.Add(this.card16, 1, 3);
            this.gameLayoutPanel.Controls.Add(this.card15, 0, 3);
            this.gameLayoutPanel.Controls.Add(this.card17, 2, 3);
            this.gameLayoutPanel.Controls.Add(this.card19, 4, 3);
            this.gameLayoutPanel.Controls.Add(this.card18, 3, 3);
            this.gameLayoutPanel.Controls.Add(this.card11, 1, 2);
            this.gameLayoutPanel.Controls.Add(this.card10, 0, 2);
            this.gameLayoutPanel.Controls.Add(this.card12, 2, 2);
            this.gameLayoutPanel.Controls.Add(this.card14, 4, 2);
            this.gameLayoutPanel.Controls.Add(this.card13, 3, 2);
            this.gameLayoutPanel.Controls.Add(this.card9, 4, 1);
            this.gameLayoutPanel.Controls.Add(this.card7, 3, 1);
            this.gameLayoutPanel.Controls.Add(this.card5, 2, 1);
            this.gameLayoutPanel.Controls.Add(this.card3, 1, 1);
            this.gameLayoutPanel.Controls.Add(this.card1, 0, 1);
            this.gameLayoutPanel.Controls.Add(this.card8, 4, 0);
            this.gameLayoutPanel.Controls.Add(this.card6, 3, 0);
            this.gameLayoutPanel.Controls.Add(this.card4, 2, 0);
            this.gameLayoutPanel.Controls.Add(this.card2, 1, 0);
            this.gameLayoutPanel.Controls.Add(this.card0, 0, 0);
            this.gameLayoutPanel.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gameLayoutPanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gameLayoutPanel.Location = new System.Drawing.Point(19, 140);
            this.gameLayoutPanel.Margin = new System.Windows.Forms.Padding(0);
            this.gameLayoutPanel.Name = "gameLayoutPanel";
            this.gameLayoutPanel.RowCount = 4;
            this.gameLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.gameLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.gameLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.gameLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.gameLayoutPanel.Size = new System.Drawing.Size(496, 591);
            this.gameLayoutPanel.TabIndex = 9;
            // 
            // card16
            // 
            this.card16.Location = new System.Drawing.Point(103, 454);
            this.card16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card16.Name = "card16";
            this.card16.Size = new System.Drawing.Size(84, 140);
            this.card16.TabIndex = 19;
            this.card16.TabStop = false;
            this.card16.Visible = false;
            // 
            // card15
            // 
            this.card15.Location = new System.Drawing.Point(3, 454);
            this.card15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card15.Name = "card15";
            this.card15.Size = new System.Drawing.Size(84, 140);
            this.card15.TabIndex = 18;
            this.card15.TabStop = false;
            this.card15.Visible = false;
            // 
            // card17
            // 
            this.card17.Location = new System.Drawing.Point(203, 454);
            this.card17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card17.Name = "card17";
            this.card17.Size = new System.Drawing.Size(84, 140);
            this.card17.TabIndex = 17;
            this.card17.TabStop = false;
            this.card17.Visible = false;
            // 
            // card19
            // 
            this.card19.Location = new System.Drawing.Point(403, 454);
            this.card19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card19.Name = "card19";
            this.card19.Size = new System.Drawing.Size(90, 140);
            this.card19.TabIndex = 16;
            this.card19.TabStop = false;
            this.card19.Visible = false;
            // 
            // card18
            // 
            this.card18.Location = new System.Drawing.Point(303, 454);
            this.card18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card18.Name = "card18";
            this.card18.Size = new System.Drawing.Size(84, 140);
            this.card18.TabIndex = 15;
            this.card18.TabStop = false;
            this.card18.Visible = false;
            // 
            // card11
            // 
            this.card11.Location = new System.Drawing.Point(103, 304);
            this.card11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card11.Name = "card11";
            this.card11.Size = new System.Drawing.Size(84, 122);
            this.card11.TabIndex = 14;
            this.card11.TabStop = false;
            this.card11.Visible = false;
            // 
            // card10
            // 
            this.card10.Location = new System.Drawing.Point(3, 304);
            this.card10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card10.Name = "card10";
            this.card10.Size = new System.Drawing.Size(84, 122);
            this.card10.TabIndex = 13;
            this.card10.TabStop = false;
            this.card10.Visible = false;
            // 
            // card12
            // 
            this.card12.Location = new System.Drawing.Point(203, 304);
            this.card12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card12.Name = "card12";
            this.card12.Size = new System.Drawing.Size(84, 122);
            this.card12.TabIndex = 12;
            this.card12.TabStop = false;
            this.card12.Visible = false;
            // 
            // card14
            // 
            this.card14.Location = new System.Drawing.Point(403, 304);
            this.card14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card14.Name = "card14";
            this.card14.Size = new System.Drawing.Size(90, 122);
            this.card14.TabIndex = 11;
            this.card14.TabStop = false;
            this.card14.Visible = false;
            // 
            // card13
            // 
            this.card13.Location = new System.Drawing.Point(303, 304);
            this.card13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card13.Name = "card13";
            this.card13.Size = new System.Drawing.Size(84, 122);
            this.card13.TabIndex = 10;
            this.card13.TabStop = false;
            this.card13.Visible = false;
            // 
            // card9
            // 
            this.card9.Location = new System.Drawing.Point(403, 154);
            this.card9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card9.Name = "card9";
            this.card9.Size = new System.Drawing.Size(90, 122);
            this.card9.TabIndex = 9;
            this.card9.TabStop = false;
            this.card9.Visible = false;
            this.card9.Click += new System.EventHandler(this.cardClick);
            // 
            // card7
            // 
            this.card7.Location = new System.Drawing.Point(303, 154);
            this.card7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card7.Name = "card7";
            this.card7.Size = new System.Drawing.Size(84, 122);
            this.card7.TabIndex = 8;
            this.card7.TabStop = false;
            this.card7.Visible = false;
            this.card7.Click += new System.EventHandler(this.cardClick);
            // 
            // card5
            // 
            this.card5.Location = new System.Drawing.Point(203, 154);
            this.card5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card5.Name = "card5";
            this.card5.Size = new System.Drawing.Size(84, 122);
            this.card5.TabIndex = 7;
            this.card5.TabStop = false;
            this.card5.Visible = false;
            this.card5.Click += new System.EventHandler(this.cardClick);
            // 
            // card3
            // 
            this.card3.Location = new System.Drawing.Point(103, 154);
            this.card3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card3.Name = "card3";
            this.card3.Size = new System.Drawing.Size(84, 122);
            this.card3.TabIndex = 6;
            this.card3.TabStop = false;
            this.card3.Visible = false;
            this.card3.Click += new System.EventHandler(this.cardClick);
            // 
            // card1
            // 
            this.card1.Location = new System.Drawing.Point(3, 154);
            this.card1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card1.Name = "card1";
            this.card1.Size = new System.Drawing.Size(84, 122);
            this.card1.TabIndex = 5;
            this.card1.TabStop = false;
            this.card1.Visible = false;
            this.card1.Click += new System.EventHandler(this.cardClick);
            // 
            // card8
            // 
            this.card8.Location = new System.Drawing.Point(403, 4);
            this.card8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card8.Name = "card8";
            this.card8.Size = new System.Drawing.Size(90, 122);
            this.card8.TabIndex = 4;
            this.card8.TabStop = false;
            this.card8.Visible = false;
            this.card8.Click += new System.EventHandler(this.cardClick);
            // 
            // card6
            // 
            this.card6.Location = new System.Drawing.Point(303, 4);
            this.card6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card6.Name = "card6";
            this.card6.Size = new System.Drawing.Size(84, 122);
            this.card6.TabIndex = 3;
            this.card6.TabStop = false;
            this.card6.Visible = false;
            this.card6.Click += new System.EventHandler(this.cardClick);
            // 
            // card4
            // 
            this.card4.Location = new System.Drawing.Point(203, 4);
            this.card4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card4.Name = "card4";
            this.card4.Size = new System.Drawing.Size(84, 122);
            this.card4.TabIndex = 2;
            this.card4.TabStop = false;
            this.card4.Visible = false;
            this.card4.Click += new System.EventHandler(this.cardClick);
            // 
            // card2
            // 
            this.card2.Location = new System.Drawing.Point(103, 4);
            this.card2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card2.Name = "card2";
            this.card2.Size = new System.Drawing.Size(84, 122);
            this.card2.TabIndex = 1;
            this.card2.TabStop = false;
            this.card2.Visible = false;
            this.card2.Click += new System.EventHandler(this.cardClick);
            // 
            // card0
            // 
            this.card0.Location = new System.Drawing.Point(3, 4);
            this.card0.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.card0.Name = "card0";
            this.card0.Size = new System.Drawing.Size(84, 122);
            this.card0.TabIndex = 0;
            this.card0.TabStop = false;
            this.card0.Visible = false;
            this.card0.Click += new System.EventHandler(this.cardClick);
            // 
            // replayButton
            // 
            this.replayButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.replayButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.replayButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.replayButton.Location = new System.Drawing.Point(211, 93);
            this.replayButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.replayButton.Name = "replayButton";
            this.replayButton.Size = new System.Drawing.Size(121, 43);
            this.replayButton.TabIndex = 15;
            this.replayButton.Text = "Replay";
            this.replayButton.UseVisualStyleBackColor = false;
            // 
            // menuButton
            // 
            this.menuButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.menuButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menuButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.menuButton.Location = new System.Drawing.Point(425, 93);
            this.menuButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.menuButton.Name = "menuButton";
            this.menuButton.Size = new System.Drawing.Size(90, 43);
            this.menuButton.TabIndex = 14;
            this.menuButton.Text = "Main Menu";
            this.menuButton.UseVisualStyleBackColor = false;
            this.menuButton.Click += new System.EventHandler(this.menuButton_Click);
            // 
            // returnButton
            // 
            this.returnButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.returnButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.returnButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.returnButton.Location = new System.Drawing.Point(19, 93);
            this.returnButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.returnButton.Name = "returnButton";
            this.returnButton.Size = new System.Drawing.Size(90, 43);
            this.returnButton.TabIndex = 13;
            this.returnButton.Text = "Return";
            this.returnButton.UseVisualStyleBackColor = false;
            this.returnButton.Click += new System.EventHandler(this.returnButton_Click);
            // 
            // turnLabel
            // 
            this.turnLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.turnLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.turnLabel.Location = new System.Drawing.Point(117, 47);
            this.turnLabel.Name = "turnLabel";
            this.turnLabel.Size = new System.Drawing.Size(282, 27);
            this.turnLabel.TabIndex = 12;
            this.turnLabel.Text = "PLAYERNAME\'s turn";
            this.turnLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // player2Score
            // 
            this.player2Score.ForeColor = System.Drawing.SystemColors.ControlText;
            this.player2Score.Location = new System.Drawing.Point(306, 20);
            this.player2Score.Name = "player2Score";
            this.player2Score.Size = new System.Drawing.Size(100, 27);
            this.player2Score.TabIndex = 11;
            this.player2Score.Text = "0";
            this.player2Score.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // player1Score
            // 
            this.player1Score.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.player1Score.ForeColor = System.Drawing.SystemColors.ControlText;
            this.player1Score.Location = new System.Drawing.Point(127, 20);
            this.player1Score.Name = "player1Score";
            this.player1Score.Size = new System.Drawing.Size(100, 27);
            this.player1Score.TabIndex = 10;
            this.player1Score.Text = "0";
            this.player1Score.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // player2Label
            // 
            this.player2Label.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.player2Label.ForeColor = System.Drawing.SystemColors.ControlText;
            this.player2Label.Location = new System.Drawing.Point(306, 0);
            this.player2Label.Name = "player2Label";
            this.player2Label.Size = new System.Drawing.Size(185, 20);
            this.player2Label.TabIndex = 8;
            this.player2Label.Text = "Player 2";
            this.player2Label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(534, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "VS";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mainTitle
            // 
            this.mainTitle.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.mainTitle.Font = new System.Drawing.Font("Impact", 25.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainTitle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.mainTitle.Location = new System.Drawing.Point(780, 0);
            this.mainTitle.Name = "mainTitle";
            this.mainTitle.Size = new System.Drawing.Size(372, 90);
            this.mainTitle.TabIndex = 4;
            this.mainTitle.Text = "Memory Game";
            this.mainTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label10.Font = new System.Drawing.Font("Impact", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(401, 90);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(1135, 20);
            this.label10.TabIndex = 5;
            this.label10.Text = "Joni Dunkel";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // leaderboardsPanel
            // 
            this.leaderboardsPanel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.leaderboardsPanel.Controls.Add(this.leaderboardsTitle);
            this.leaderboardsPanel.Controls.Add(this.leaderboardsBackButton);
            this.leaderboardsPanel.Controls.Add(this.leaderboardsSubtitle);
            this.leaderboardsPanel.Controls.Add(this.leaderboardsTable);
            this.leaderboardsPanel.Location = new System.Drawing.Point(789, 464);
            this.leaderboardsPanel.Name = "leaderboardsPanel";
            this.leaderboardsPanel.Size = new System.Drawing.Size(546, 641);
            this.leaderboardsPanel.TabIndex = 6;
            this.leaderboardsPanel.Visible = false;
            // 
            // leaderboardsTitle
            // 
            this.leaderboardsTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.leaderboardsTitle.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leaderboardsTitle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.leaderboardsTitle.Location = new System.Drawing.Point(0, 0);
            this.leaderboardsTitle.Name = "leaderboardsTitle";
            this.leaderboardsTitle.Size = new System.Drawing.Size(546, 59);
            this.leaderboardsTitle.TabIndex = 1;
            this.leaderboardsTitle.Text = "Leaderboards";
            this.leaderboardsTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // leaderboardsBackButton
            // 
            this.leaderboardsBackButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.leaderboardsBackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.leaderboardsBackButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.leaderboardsBackButton.Location = new System.Drawing.Point(398, 564);
            this.leaderboardsBackButton.Name = "leaderboardsBackButton";
            this.leaderboardsBackButton.Size = new System.Drawing.Size(101, 45);
            this.leaderboardsBackButton.TabIndex = 3;
            this.leaderboardsBackButton.Text = "Main Menu";
            this.leaderboardsBackButton.UseVisualStyleBackColor = false;
            this.leaderboardsBackButton.Click += new System.EventHandler(this.leaderboardsBackButton_Click);
            // 
            // leaderboardsSubtitle
            // 
            this.leaderboardsSubtitle.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.leaderboardsSubtitle.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leaderboardsSubtitle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.leaderboardsSubtitle.Location = new System.Drawing.Point(0, 0);
            this.leaderboardsSubtitle.Name = "leaderboardsSubtitle";
            this.leaderboardsSubtitle.Size = new System.Drawing.Size(546, 134);
            this.leaderboardsSubtitle.TabIndex = 2;
            this.leaderboardsSubtitle.Text = "Sort by: Name (Desc.)";
            this.leaderboardsSubtitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // leaderboardsTable
            // 
            this.leaderboardsTable.ColumnCount = 5;
            this.leaderboardsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.leaderboardsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.leaderboardsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.leaderboardsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.leaderboardsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.leaderboardsTable.Controls.Add(this.label15, 4, 0);
            this.leaderboardsTable.Controls.Add(this.label14, 3, 0);
            this.leaderboardsTable.Controls.Add(this.label13, 2, 0);
            this.leaderboardsTable.Controls.Add(this.label12, 1, 0);
            this.leaderboardsTable.Controls.Add(this.label11, 0, 0);
            this.leaderboardsTable.ForeColor = System.Drawing.SystemColors.ControlText;
            this.leaderboardsTable.Location = new System.Drawing.Point(54, 137);
            this.leaderboardsTable.Name = "leaderboardsTable";
            this.leaderboardsTable.RowCount = 2;
            this.leaderboardsTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.leaderboardsTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.leaderboardsTable.Size = new System.Drawing.Size(445, 312);
            this.leaderboardsTable.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(359, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(43, 20);
            this.label15.TabIndex = 4;
            this.label15.Text = "Level";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(270, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(48, 20);
            this.label14.TabIndex = 3;
            this.label14.Text = "Win%";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(181, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 20);
            this.label13.TabIndex = 2;
            this.label13.Text = "Losses";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(92, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 20);
            this.label12.TabIndex = 1;
            this.label12.Text = "Wins";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 40);
            this.label11.TabIndex = 0;
            this.label11.Text = "Profile Name";
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.ClientSize = new System.Drawing.Size(1924, 818);
            this.Controls.Add(this.leaderboardsPanel);
            this.Controls.Add(this.gamePanel);
            this.Controls.Add(this.pregamePanel);
            this.Controls.Add(this.optionsPanel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.mainTitle);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "mainForm";
            this.Text = "Memory Game";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.optionsPanel.ResumeLayout(false);
            this.optionsPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.frontPreview)).EndInit();
            this.backGroup.ResumeLayout(false);
            this.backGroup.PerformLayout();
            this.frontGroup.ResumeLayout(false);
            this.frontGroup.PerformLayout();
            this.pregamePanel.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.pregameMultiOptions.ResumeLayout(false);
            this.pregameMultiOptions.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pregameSingleOptions.ResumeLayout(false);
            this.pregameSingleOptions.PerformLayout();
            this.singleBackGroup.ResumeLayout(false);
            this.singleBackGroup.PerformLayout();
            this.singleFrontGroup.ResumeLayout(false);
            this.singleFrontGroup.PerformLayout();
            this.difficultyGroup.ResumeLayout(false);
            this.difficultyPanel.ResumeLayout(false);
            this.sharedPanel.ResumeLayout(false);
            this.sharedPanel.PerformLayout();
            this.gamePanel.ResumeLayout(false);
            this.gameLayoutPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.card16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.card0)).EndInit();
            this.leaderboardsPanel.ResumeLayout(false);
            this.leaderboardsTable.ResumeLayout(false);
            this.leaderboardsTable.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button optionsButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Panel optionsPanel;
        private System.Windows.Forms.Button optionsExitButton;
        private System.Windows.Forms.Button leaderboardsButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox profileBox;
        private System.Windows.Forms.Panel pregamePanel;
        private System.Windows.Forms.TextBox pairAmountTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button multiplayerButton;
        private System.Windows.Forms.Button singleplayerButton;
        private System.Windows.Forms.Panel pregameSingleOptions;
        private System.Windows.Forms.GroupBox difficultyGroup;
        private System.Windows.Forms.TableLayoutPanel difficultyPanel;
        private System.Windows.Forms.RadioButton difficultyHard;
        private System.Windows.Forms.RadioButton difficultyMedium;
        private System.Windows.Forms.RadioButton difficultyEasy;
        private System.Windows.Forms.Label pairErrorLabel;
        private System.Windows.Forms.Button singleplayerStart;
        private System.Windows.Forms.Label profileNameLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button singleNewProfileButton;
        private System.Windows.Forms.TextBox singleNewProfileTextBox;
        private System.Windows.Forms.Panel gamePanel;
        private System.Windows.Forms.Label player1Label;
        private System.Windows.Forms.Label player2Label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TableLayoutPanel gameLayoutPanel;
        private System.Windows.Forms.PictureBox card9;
        private System.Windows.Forms.PictureBox card7;
        private System.Windows.Forms.PictureBox card5;
        private System.Windows.Forms.PictureBox card3;
        private System.Windows.Forms.PictureBox card1;
        private System.Windows.Forms.PictureBox card8;
        private System.Windows.Forms.PictureBox card6;
        private System.Windows.Forms.PictureBox card4;
        private System.Windows.Forms.PictureBox card2;
        private System.Windows.Forms.PictureBox card0;
        private System.Windows.Forms.TextBox optionsNewProfileTextBox;
        private System.Windows.Forms.Button optionsNewProfileButton;
        private System.Windows.Forms.Label player2Score;
        private System.Windows.Forms.Label player1Score;
        private System.Windows.Forms.Panel pregameMultiOptions;
        private System.Windows.Forms.TextBox multiNewProfileTextBox;
        private System.Windows.Forms.Button multiNewProfileButton;
        private System.Windows.Forms.ListBox multiProfileList1;
        private System.Windows.Forms.Button multiplayerStart;
        private System.Windows.Forms.PictureBox card16;
        private System.Windows.Forms.PictureBox card15;
        private System.Windows.Forms.PictureBox card17;
        private System.Windows.Forms.PictureBox card19;
        private System.Windows.Forms.PictureBox card18;
        private System.Windows.Forms.PictureBox card11;
        private System.Windows.Forms.PictureBox card10;
        private System.Windows.Forms.PictureBox card12;
        private System.Windows.Forms.PictureBox card14;
        private System.Windows.Forms.PictureBox card13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox multiProfileList2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label player2Name;
        private System.Windows.Forms.Label player1Name;
        private System.Windows.Forms.ComboBox singleProfileList;
        private System.Windows.Forms.Label turnLabel;
        private System.Windows.Forms.Label singleXp;
        private System.Windows.Forms.Label singleStreak;
        private System.Windows.Forms.Label singleLosses;
        private System.Windows.Forms.Label singleWins;
        private System.Windows.Forms.GroupBox frontGroup;
        private System.Windows.Forms.RadioButton defaultFront;
        private System.Windows.Forms.RadioButton pokerFront;
        private System.Windows.Forms.RadioButton arcanaFront;
        private System.Windows.Forms.GroupBox backGroup;
        private System.Windows.Forms.RadioButton arcanaBack;
        private System.Windows.Forms.RadioButton pokerBack;
        private System.Windows.Forms.RadioButton defBack;
        private System.Windows.Forms.ProgressBar xpBar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ProgressBar optionsXpBar;
        private System.Windows.Forms.Label optionsLevel;
        private System.Windows.Forms.Label optionsStreak;
        private System.Windows.Forms.Label optionsLosses;
        private System.Windows.Forms.Label optionsWins;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton multiBackArcana;
        private System.Windows.Forms.RadioButton multiBackPoker;
        private System.Windows.Forms.RadioButton multiBackDefault;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton multiFrontArcana;
        private System.Windows.Forms.RadioButton multiFrontPoker;
        private System.Windows.Forms.RadioButton multiFrontDefault;
        private System.Windows.Forms.Button menuButton;
        private System.Windows.Forms.Button returnButton;
        private System.Windows.Forms.Button replayButton;
        private System.Windows.Forms.Label mainTitle;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox singleBackGroup;
        private System.Windows.Forms.RadioButton singleArcanaBack;
        private System.Windows.Forms.RadioButton singlePokerBack;
        private System.Windows.Forms.RadioButton singledefaultBack;
        private System.Windows.Forms.GroupBox singleFrontGroup;
        private System.Windows.Forms.RadioButton singleArcanaFront;
        private System.Windows.Forms.RadioButton singlePokerFront;
        private System.Windows.Forms.RadioButton singleDefaultFront;
        private System.Windows.Forms.CheckBox matchingBox;
        private System.Windows.Forms.Panel sharedPanel;
        private System.Windows.Forms.RadioButton fancyGuildsFront;
        private System.Windows.Forms.RadioButton guildsFront;
        private System.Windows.Forms.RadioButton fancyGuildsBack;
        private System.Windows.Forms.RadioButton guildsBack;
        private System.Windows.Forms.RadioButton singleFancyGuildsFront;
        private System.Windows.Forms.RadioButton singleGuildsFront;
        private System.Windows.Forms.RadioButton multiFrontGuilds;
        private System.Windows.Forms.RadioButton multiFrontFancyGuilds;
        private System.Windows.Forms.RadioButton multiBackGuilds;
        private System.Windows.Forms.RadioButton multiBackFancyGuilds;
        private System.Windows.Forms.RadioButton singleFancyGuildsBack;
        private System.Windows.Forms.RadioButton singleGuildsBack;
        private System.Windows.Forms.Label multiplayerProfilesError;
        private System.Windows.Forms.Label singleplayerProfileError;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Panel leaderboardsPanel;
        private System.Windows.Forms.TableLayoutPanel leaderboardsTable;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label leaderboardsSubtitle;
        private System.Windows.Forms.Label leaderboardsTitle;
        private System.Windows.Forms.Button leaderboardsBackButton;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton difficultyMedium2;
        private System.Windows.Forms.RadioButton difficultyMedium3;
        private System.Windows.Forms.RadioButton difficultyGoldfish;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.PictureBox backPreview;
        private System.Windows.Forms.PictureBox frontPreview;
    }
}

